import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:helmet/databaseProvider/dataHandler.dart';
import 'package:helmet/databaseProvider/model.dart';
import 'package:helmet/screens/graphScreens/heartBeat.dart';
import 'package:helmet/screens/graphScreens/humidity.dart';
import 'package:helmet/screens/graphScreens/roomTemperature.dart';
import 'package:helmet/screens/graphScreens/spo.dart';
import 'package:helmet/screens/graphScreens/temperature.dart';
import 'package:helmet/screens/loginScreen.dart';
import 'package:helmet/utils/const.dart';
import 'package:helmet/widgets/card_items.dart';
import 'package:helmet/widgets/card_main.dart';
import 'package:helmet/widgets/card_section.dart';
import 'package:helmet/widgets/custom_clipper.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:fluttericon/typicons_icons.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  void initState() {
    super.initState();
    LiveData.shared.initiateSmartMeter();
    DataHandler.shared.liveDataProvider();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Stack(
        children: <Widget>[
          ClipPath(
            clipper: MyCustomClipper(clipType: ClipType.bottom),
            child: Container(
              color: Theme.of(context).colorScheme.secondary,
              height: Constants.headerHeight + statusBarHeight,
            ),
          ),
          Positioned(
            right: -45,
            top: -30,
            child: ClipOval(
              child: Container(
                color: Colors.black.withOpacity(0.05),
                height: 220,
                width: 220,
              ),
            ),
          ),

          // BODY
          Padding(
            padding: EdgeInsets.all(Constants.paddingSide),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 15),

                Row(
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: const Text("Good Morning!",
                        style: TextStyle(
                            fontSize: 25,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.w900,
                            color: Colors.white
                        ),
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: PopupMenuButton<String>(
                        icon: Icon(Icons.adaptive.more, color: Colors.white),
                        onSelected: (choice) {
                          handleMenu(choice);
                        },
                        itemBuilder: (BuildContext context) {
                          return {'Help', 'Logout'}
                              .map((String choice) {
                            return PopupMenuItem<String>(
                              value: choice,
                              child: Text(choice, style: const TextStyle(fontSize: 22, letterSpacing: 1),),
                            );
                          }).toList();
                        },
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Main Cards - Heartbeat and Blood Pressure
                ChangeNotifierProvider.value(
                  value: LiveData.shared.currentLiveDataDisplay!,
                  child: Consumer<LiveDataDisplay>(
                      builder: (context, value, child) {
                        return SizedBox(
                          height: 170,
                          width: 1100,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: <Widget>[
                              CardIcon(
                                icon: Icon(FontAwesome5.heartbeat, size: 20,),
                                title: "Heartbeat",
                                value: (LiveData.shared.pulse??'...'),
                                unit: "bpm",
                                color: Constants.lightGreen,
                                graphPage: PulseGraphPage(),
                              ),
                              CardIcon(
                                icon: Icon(Typicons.temperatire, size: 20,),
                                title: "Body Temperature",
                                value:  (LiveData.shared.bodyTemperature??'...'),
                                unit: "\u2103",
                                color: Colors.deepPurple.shade100,
                                graphPage: TemperatureGraphPage(),
                              ),
                              CardIcon(
                                icon: Icon(Icons.air, size: 20,),
                                title: "SpO2",
                                value:  (LiveData.shared.spO2??'...'),
                                unit: "%",
                                color: Constants.lightYellow,
                                graphPage: SpoGraphPage(),
                              ),
                              CardIcon(
                                icon: Icon(Icons.water, size: 20,),
                                title: "Humidity",
                                value:  (LiveData.shared.humidity??'...'),
                                unit: "%",
                                color: Colors.pink.shade100,
                                graphPage: HumidityGraphPage(),
                              ),
                              CardIcon(
                                icon: Icon(Typicons.temperatire, size: 20,),
                                title:  'Room Temperature',
                                value: (LiveData.shared.temperature??'...'),
                                unit: "\u2103",
                                color: Colors.deepOrange.shade100,
                                graphPage: RoomTemperatureGraphPage(),
                              )
                            ],
                          ),
                        );
                      }),
                ),

                // Section Cards - Daily Medication
                const SizedBox(height: 30),

                Align(
                  alignment: Alignment.centerLeft,
                  child: Text("Air Quality analysis",
                    style: TextStyle(
                      color: Constants.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                ChangeNotifierProvider.value(
                  value: LiveData.shared.currentLiveDataDisplay!,
                  child: Consumer<LiveDataDisplay>(
                      builder: (context, value, child) {
                        return CardSection(
                          icon: Icon(Icons.air, size: 40),
                          title:  (LiveData.shared.airQuality??'...'),
                          value: "",
                          unit: "Air Quality",
                          time:  (LiveData.shared.timestamp??'...'),
                          isDone: false,
                        );
                      }),
                ),

                const SizedBox(height: 15),

                CardItems(
                  image: Icon(Icons.error),
                  title: "Report a problem",
                  value: "Mention a problem",
                  color: Constants.lightBlue,
                  onTap: (){
                    _launchFormUrl();
                  },
                ),


              ],
            ),
          )
        ],
      ),
    );
  }

  _launchPdfUrl() async {
    const url = 'https://drive.google.com/file/d/16NipAUr4UDGXsf6CJgT28bjVEKPpa9FP/view?usp=sharing';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  _launchFormUrl() async {
    const url = 'https://docs.google.com/forms/d/e/1FAIpQLScEbqBaTpyy11A2y2QY3YSymy2a5nX7IkTKh1BHvra5OiWy4A/viewform';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  void handleMenu(String value) {
    switch (value) {
      case 'Logout':
        DataHandler.shared.dispose();
        Navigator.of(context, rootNavigator: true).pushReplacement(CupertinoPageRoute(builder: (BuildContext context) => const LoginScreen()));
        break;
      case 'Help':
        _launchPdfUrl();
        break;
      default:
        break;
    }
  }
}
