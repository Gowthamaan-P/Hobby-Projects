import 'package:flutter/material.dart';
import 'package:helmet/databaseProvider/dataHandler.dart';
import 'package:helmet/utils/const.dart';
import 'package:helmet/widgets/card_items.dart';
import 'package:url_launcher/url_launcher.dart';

class IncidentReportPage extends StatelessWidget {
  const IncidentReportPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Incident Report"),
        automaticallyImplyLeading: true,
      ),
      backgroundColor: Colors.grey.shade200,
      body: ListView.builder(
        itemCount: DataHandler.shared.incidents.length,
        itemBuilder: (BuildContext context, int index) {
          return CardItems(
            image: Icon(Icons.waterfall_chart),
            title: "Fall or Impact Detected: Ashika - Helmet:2196",
            value: "Latitude: ${DataHandler.shared.incidents[index].latitude}, Longitude: ${DataHandler.shared.incidents[index].longitude}",
            color: Constants.lightYellow,
            onTap: (){
              _launchLocationUrl(DataHandler.shared.incidents[index].latitude,DataHandler.shared.incidents[index].longitude);
            }
          );
        },
      ),
    );
  }

  _launchLocationUrl(double latitude, double longitude) async {
    final url = 'http://maps.google.com/maps?q='+latitude.toString()+","+longitude.toString();
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
