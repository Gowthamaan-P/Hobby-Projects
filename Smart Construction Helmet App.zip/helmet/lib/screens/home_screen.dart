import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:helmet/databaseProvider/dataHandler.dart';
import 'package:helmet/databaseProvider/model.dart';
import 'package:helmet/screens/graphScreens/humidity.dart';
import 'package:helmet/screens/graphScreens/roomTemperature.dart';
import 'package:helmet/screens/incidentReport.dart';
import 'package:helmet/screens/loginScreen.dart';
import 'package:helmet/utils/const.dart';
import 'package:helmet/utils/geoLocator.dart';
import 'package:helmet/widgets/card_items.dart';
import 'package:helmet/widgets/card_main.dart';
import 'package:helmet/widgets/custom_clipper.dart';
import 'package:fluttericon/typicons_icons.dart';
import 'package:provider/provider.dart';

class HostScreen extends StatefulWidget {
  const HostScreen({Key? key}) : super(key: key);

  @override
  State<HostScreen> createState() => _HostScreenState();
}

class _HostScreenState extends State<HostScreen> {

  @override
  void initState() {
    super.initState();
    LiveData.shared.initiateSmartMeter();
    DataHandler.shared.liveDataProvider();
  }

  @override
  void dispose() {
    super.dispose();
    LiveData.shared.context = null;
    DataHandler.shared.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;
    LiveData.shared.context = context;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: <Widget>[
          ClipPath(
            clipper: MyCustomClipper(clipType: ClipType.bottom),
            child: Container(
              color: Theme.of(context).colorScheme.secondary,
              height: Constants.headerHeight + statusBarHeight,
            ),
          ),
          Positioned(
              right: -45,
              top: -30,
              child: ClipOval(
                  child: Container(
                    color: Colors.black.withOpacity(0.05),
                    height: 220,
                    width: 220,
                  ),
              ),
          ),

          ChangeNotifierProvider.value(
            value: LiveData.shared.currentLiveDataDisplay!,
            child: Consumer<LiveDataDisplay>(
                builder: (context, value, child) {
                  return Padding(
                    padding: EdgeInsets.all(Constants.paddingSide),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        const SizedBox(height: 5),

                        Row(
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: const Text("Welcome!",
                                style: TextStyle(
                                    fontSize: 25,
                                    letterSpacing: 1.0,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white
                                ),
                              ),
                            ),
                            const Spacer(),
                            Align(
                              alignment: Alignment.topRight,
                              child: PopupMenuButton<String>(
                                icon: Icon(Icons.adaptive.more, color: Colors.white),
                                onSelected: (choice) {
                                  handleMenu(choice);
                                },
                                itemBuilder: (BuildContext context) {
                                  return {'Settings', 'Logout'}
                                      .map((String choice) {
                                    return PopupMenuItem<String>(
                                      value: choice,
                                      child: Text(choice, style: const TextStyle(fontSize: 22, letterSpacing: 1),),
                                    );
                                  }).toList();
                                },
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 10),

                        // Main Cards - Heartbeat and Blood Pressure
                        SizedBox(
                          height: 170,
                          width: 1100,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              CardIcon(
                                icon: Icon(Icons.water, size: 20,),
                                title: "Humidity",
                                value:  (LiveData.shared.humidity??'...'),
                                unit: "%",
                                color: Colors.pink.shade100,
                                graphPage: HumidityGraphPage(),
                              ),
                              CardIcon(
                                icon: Icon(Typicons.temperatire, size: 20,),
                                title:  'Room Temperature',
                                value: (LiveData.shared.temperature??'...'),
                                unit: "\u2103",
                                color: Colors.deepOrange.shade100,
                                graphPage: RoomTemperatureGraphPage(),
                              )
                            ],
                          ),
                        ),

                        // Section Cards - Daily Medication
                        const SizedBox(height: 10),

                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text("Available Helmets",
                            style: TextStyle(
                              color: Constants.textPrimary,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        SizedBox(
                          height: 377,
                          child: ListView(
                            padding: EdgeInsets.zero,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  margin: const EdgeInsets.only(right: 15.0),
                                  width: double.infinity,
                                  height: 370,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                    shape: BoxShape.rectangle,
                                    color: Colors.grey.shade200,
                                  ),
                                  child: Stack(
                                    clipBehavior: Clip.hardEdge, children: <Widget>[
                                    Positioned(
                                      child: ClipPath(
                                        clipper: MyCustomClipper(clipType: ClipType.semiCircle),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: const BorderRadius.all(Radius.circular(10.0)),
                                            color: Constants.lightBlue.withOpacity(0.1),
                                          ),
                                          height: 120,
                                          width: 120,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: <Widget>[
                                              Icon(Icons.admin_panel_settings_rounded, size: 50),
                                              Text(
                                                LiveData.shared.timestamp??"...",
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Constants.textPrimary
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 20),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text("Ashika",
                                                      overflow: TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: 40,
                                                          fontWeight: FontWeight.bold,
                                                          color: Constants.textPrimary
                                                      ),
                                                    ),
                                                    const SizedBox(height: 5),
                                                    Text('Helmet ID: 2196',
                                                      style: TextStyle(
                                                          fontSize: 20,
                                                          color: Constants.textPrimary
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Icon(FontAwesome5.heartbeat, color: DataHandler.shared.pulseFlag?Colors.red.shade900:Colors.green.shade900, size: 35),
                                              Icon(Typicons.temperatire, color: DataHandler.shared.roomTemperatureFlag?Colors.red.shade900:Colors.green.shade900, size: 35),
                                              Icon(Icons.air, color: DataHandler.shared.spoFlag?Colors.red.shade900:Colors.green.shade900, size: 35),
                                              Icon(Icons.water, color: DataHandler.shared.humidityFlag?Colors.red.shade900:Colors.green.shade900, size: 35),
                                              Icon(Icons.accessibility_new_rounded, color: DataHandler.shared.temperatureFlag?Colors.red.shade900:Colors.green.shade900, size: 35),
                                              const SizedBox(height: 20),
                                            ],
                                          ),
                                          const Spacer(),
                                          CardItems(
                                              image: Icon(Icons.notes_rounded),
                                              title: "Incident Reports",
                                              value: "List all the safety related incidents",
                                              color: Constants.lightYellow,
                                             onTap: (){
                                               Navigator.of(LiveData.shared.context!, rootNavigator: true)
                                                   .push(CupertinoPageRoute(builder: (BuildContext context) => const IncidentReportPage()));
                                             },
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20)
                      ],
                    ),
                  );
                }),
          ),

          // BODY

        ],
      ),
    );
  }




  void handleMenu(String value) {
    switch (value) {
      case 'Logout':
        Navigator.of(context, rootNavigator: true).pushReplacement(CupertinoPageRoute(builder: (BuildContext context) => const LoginScreen()));
        break;
      case 'Settings':
        Navigator.of(context, rootNavigator: true).push(CupertinoPageRoute(builder: (BuildContext context) => const GeolocatorWidget()));
        break;
      default:
        break;
    }
  }
}
