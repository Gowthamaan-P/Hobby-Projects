import 'package:flutter/material.dart';
import 'package:helmet/databaseProvider/model.dart';
import 'package:helmet/utils/const.dart';
import 'package:helmet/widgets/custom_clipper.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:helmet/databaseProvider/graphDataProvider.dart';

class PulseGraph extends StatefulWidget {
  const PulseGraph({Key? key}) : super(key: key);

  @override
  _PulseGraphState createState() => _PulseGraphState();
}

class _PulseGraphState extends State<PulseGraph> {
  List<Color> gradientColors = [
    const Color(0xff23b6e6),
    const Color(0xff02d39a),
  ];

  bool showAvg = false;

  List<GraphHelmetData> graphData = [];
  List<FlSpot> graphPoints = [];

  double _minX = 0.0, _maxX = 10.0, _minY = 0.0, _maxY = 0.0, _leftTitlesInterval = 0;
  final _leftLabelsCount = 6;

  bool isReady = false, isEmpty = false;

  LineChartData? graphWidgetData;

  @override
  void initState() {
    super.initState();
    prepareData();
  }

  @override
  Widget build(BuildContext context) {
    return isReady? Stack(
      children: <Widget>[
        Container(
          height: 450,
          width: double.infinity,
          decoration: const BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(18),
              ),
              color: Color(0xff232d37)),
          child: Padding(
            padding: const EdgeInsets.only(
                right: 18.0, left: 10.0, top: 35, bottom: 12),
            child: isEmpty? const Center(
              child: Text(
                "No logs",
                style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ):LineChart(graphWidgetData!),
          ),
        ),
        SizedBox(
          width: 35,
          height: 34,
          child: TextButton(
            onPressed: () {
              setState(() {
                isReady = false;
              });
              prepareData();
            },
            child: const Icon(Icons.refresh_outlined, color: Colors.white, size: 25),
          ),
        ),
      ],
    ):Center(
      child: Card(
        child: Container(
          width: 80,
          height: 80,
          padding: const EdgeInsets.all(12.0),
          child: const CircularProgressIndicator(),
        ),
      ),
    );
  }

  void prepareData()async{
    graphData = [];
    graphData = await GraphDataProvider().getGraphHelmetData();
    graphPoints = [];

    for (var element in graphData) {
      double energy = double.parse(element.pulse);
      graphPoints.add(FlSpot(graphData.indexOf(element).toDouble(),energy));
    }

    if(graphPoints.isEmpty){
      graphPoints.add(FlSpot.zero);
      isEmpty = true;
    }else{
      isEmpty = false;
    }

    for (var element in graphPoints) {
      if (element.y < _minY) _minY = element.y;
      if (element.y > _maxY) _maxY = element.y;
    }

    _minX = graphPoints.first.x;
    _maxX = graphPoints.last.x;
    _leftTitlesInterval = ((_maxY - _minY) / (_leftLabelsCount - 1));

    if(_leftTitlesInterval == 0){
      _leftTitlesInterval = 5;
    }
    isReady = true;

    graphWidgetData = await buildGraphAsync();
    setState(() {});
  }

  Future<LineChartData> buildGraphAsync() async {
    return Future.microtask(() {
      return mainData();
    });
  }

  LineChartData mainData() {

    return LineChartData(
        gridData: FlGridData(
          show: true,
          drawHorizontalLine: true,
          drawVerticalLine: false,
          horizontalInterval: 1,
          verticalInterval: 1,
          getDrawingHorizontalLine: (value) {
            return FlLine(color: const Color(0xff37434d), strokeWidth: 1);
          },
          getDrawingVerticalLine: (value) {
            return FlLine(color: const Color(0xff37434d), strokeWidth: 1);
          },
        ),
        titlesData: FlTitlesData(leftTitles: _leftTitles(), bottomTitles: _bottomTiles(), rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false))),
        borderData: FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
        minX: _minX,
        maxX: _maxX,
        minY: _minY,
        maxY: _maxY,
        lineBarsData: [
          LineChartBarData(spots: graphPoints, isCurved: false, isStrokeCapRound: true, dotData: FlDotData(show: true))
        ]
    );
  }

  AxisTitles _leftTitles() {
    return AxisTitles(
      drawBehindEverything: false,
        axisNameWidget: const Text('Pulse (bpm)', style: TextStyle(color: Colors.white54, fontSize: 12)),
        sideTitles: SideTitles(showTitles: true,
            getTitlesWidget: (value, metaData) => Text(
              value.toStringAsFixed(2),
              style: const TextStyle(color: Colors.white54),
            ), interval: _leftTitlesInterval, reservedSize: 40)
    );
  }

  AxisTitles _bottomTiles() {
    return AxisTitles(
        axisNameWidget: const Text('Time (h)', style: TextStyle(color: Colors.white54))
    );
  }

}

class PulseGraphPage extends StatelessWidget {
  const PulseGraphPage({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;


    return Scaffold(
      backgroundColor: Constants.backgroundColor,
      body: Stack(
        children: <Widget>[
          ClipPath(
            clipper: MyCustomClipper(clipType: ClipType.bottom),
            child: Container(
              color: Constants.lightGreen,
              height: Constants.headerHeight + statusBarHeight,
            ),
          ),

          Positioned(
            right: -45,
            top: -30,
            child: ClipOval(
              child: Container(
                color: Colors.black.withOpacity(0.05),
                height: 220,
                width: 220,
              ),
            ),
          ),

          // BODY
          Padding(
            padding: EdgeInsets.all(Constants.paddingSide),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    // Back Button
                    SizedBox(
                      width: 34,
                      child:RawMaterialButton(
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Icon(
                            Icons.arrow_back_ios,
                            size: 15.0,
                            color: Colors.black
                        ),
                        shape: const CircleBorder(
                          side: BorderSide(
                              color: Colors.black,
                              width: 2,
                              style: BorderStyle.solid
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        const Text("Heartbeat",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.w900,
                              color: Colors.black
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          mainAxisAlignment: MainAxisAlignment.start,
                          textBaseline: TextBaseline.alphabetic,
                          children: <Widget>[
                            Text((LiveData.shared.pulse??'...'),
                              style: TextStyle(
                                  fontSize: 48,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.black
                              ),
                            ),

                            SizedBox(width: 10),

                            Text("bpm",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                Material(
                  shadowColor: Colors.grey.withOpacity(0.01), // added
                  type: MaterialType.card,
                  elevation: 10, borderRadius: BorderRadius.circular(10.0),
                  child: Container(
                    padding: const EdgeInsets.all(20.0),
                    height: 500,
                    child: PulseGraph(),
                  ), // added
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

