import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class GraphDataProvider {
  static const url = "https://script.google.com/macros/s/AKfycbxCe7xJZ45urwJoKXuvTBvPT_WbsP_BgCTUeWbe/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<GraphHelmetData>> getGraphHelmetData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => GraphHelmetData.fromJson(json)).toList();
    });
  }
}

class GraphHelmetData {

  String temperature;
  String humidity;
  String bodyTemperature;
  String pulse;
  String spO2;
  String timestamp;

  GraphHelmetData({
    required this.temperature,
    required this.humidity,
    required this.bodyTemperature,
    required this.pulse,
    required this.spO2,
    required this.timestamp,
  });

  factory GraphHelmetData.fromJson(dynamic json) {
    return GraphHelmetData(
        temperature: "${json['temperature']}",
        humidity: "${json['humidity']}",
        bodyTemperature: "${json['bodyTemperature']}",
        pulse: "${json['pulse']}",
        spO2: "${json['spO2']}",
        timestamp: "${json['timestamp']}");
  }

  // Method to make GET parameters.
  Map toJson() => {
    'temperature': temperature,
    'humidity': humidity,
    'bodyTemperature': bodyTemperature,
    'pulse': pulse,
    'spO2': spO2,
    'timestamp':timestamp
  };
}
