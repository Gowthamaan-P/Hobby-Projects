import 'package:flutter/cupertino.dart';

class LiveDataDisplay extends ChangeNotifier{
  void rebuildLiveDataDisplay(){
    notifyListeners();
  }
}


class LiveData{
  static final LiveData _singleton = LiveData._internal();
  static LiveData get shared => _singleton;
  factory LiveData() => _singleton;
  LiveData._internal();

  String? temperature;
  String? humidity;
  String? bodyTemperature;
  String? mqtRaw;
  String? airQuality;
  String? pulse;
  String? spO2;
  String? fallDetection;
  String? dayDetection;
  String? ledStatus;
  String? findHelmet;
  String? status;
  String? timestamp;
  LiveDataDisplay? currentLiveDataDisplay;
  BuildContext? context;

  void initiateSmartMeter(){
    temperature = null;
    humidity = null;
    bodyTemperature = null;
    mqtRaw = null;
    airQuality = null;
    pulse = null;
    spO2 = null;
    fallDetection = null;
    dayDetection = null;
    ledStatus = null;
    findHelmet = null;
    status = null;
    timestamp = null;
    currentLiveDataDisplay = LiveDataDisplay();
  }
}


class Incidents{
  String message;
  double latitude;
  double longitude;
  String timeStamp;

  Incidents(this.message, this.latitude, this.longitude, this.timeStamp);
}