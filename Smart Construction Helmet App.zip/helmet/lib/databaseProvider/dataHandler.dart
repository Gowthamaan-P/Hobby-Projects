import 'dart:async';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:helmet/databaseProvider/liveDataProvider.dart';
import 'package:helmet/databaseProvider/model.dart';
import 'package:helmet/screens/home_screen.dart';
import 'package:helmet/screens/hostScreen.dart';
import 'package:helmet/utils/errorDialog.dart';
import 'package:helmet/utils/geoLocator.dart';

class DataHandler {
  static final DataHandler _singleton = DataHandler._internal();
  static DataHandler get shared => _singleton;
  factory DataHandler() => _singleton;
  DataHandler._internal();

  Timer? liveDataTimer;
  int previousState = -1;
  int pageState = 0;
  String previousStateParam = "";
  bool humidityFlag = false, roomTemperatureFlag = false, temperatureFlag = false, spoFlag = false, pulseFlag = false;
  List<Incidents> incidents = [];


  int next(int min, int max, Random rand) {
    return (min + rand.nextInt(max - min));
  }

  double nextDouble(double min, int max, Random rand) {
    return (min + rand.nextInt(max - min.toInt()));
  }

  void liveDataProvider() {
    var random = Random();
    liveDataTimer = Timer.periodic(const Duration(seconds: 3), (timer) async {
      List<LiveHelmetData> liveData =
          await LiveDataProvider().getLiveMeterData();
      if (liveData.isNotEmpty) {
        LiveHelmetData meterData = liveData.last;
        LiveData.shared.temperature = meterData.temperature;
        LiveData.shared.humidity = meterData.humidity;
        LiveData.shared.mqtRaw = meterData.mqtRaw;
        LiveData.shared.airQuality = meterData.airQuality;
        LiveData.shared.bodyTemperature = meterData.bodyTemperature;
        LiveData.shared.pulse =  meterData.pulse;
        LiveData.shared.spO2 =  meterData.spO2;
       /* if(previousStateParam!=meterData.humidity){
          LiveData.shared.bodyTemperature = nextDouble(36, 38, random).toString();
          LiveData.shared.pulse = next(60, 80, random).toString();
          LiveData.shared.spO2 = next(95, 100, random).toString();
        }else{
          LiveData.shared.bodyTemperature = '36.7';
          LiveData.shared.pulse = '72';
          LiveData.shared.spO2 = '98';
        }*/
        previousStateParam = meterData.humidity??"...";
        LiveData.shared.fallDetection = meterData.fallDetection;
        LiveData.shared.dayDetection = meterData.dayDetection;
        LiveData.shared.ledStatus = meterData.ledStatus;
        LiveData.shared.findHelmet = meterData.findHelmet;
        LiveData.shared.status = meterData.status;
        LiveData.shared.timestamp = meterData.timestamp;
        detectFall((int.tryParse(meterData.fallDetection ?? "0") ?? 1));
        previousState = (int.tryParse(meterData.fallDetection ?? '0') ?? 1);
        detectParameter(
            humidity: (int.tryParse(meterData.humidity ?? "40") ?? 40),
            roomTemperature: (int.tryParse(meterData.temperature ?? "33") ?? 33),
            bodyTemperature: (int.tryParse(meterData.bodyTemperature ?? "36") ?? 36),
            pulse: (int.tryParse(meterData.pulse ?? "72") ?? 72),
            spo: (int.tryParse(meterData.spO2 ?? "98") ?? 98),
          airQuality: meterData.airQuality
        );
        LiveData.shared.currentLiveDataDisplay!.rebuildLiveDataDisplay();
      }
    });
  }

  void detectParameter(
      {required int humidity,
      required int roomTemperature,
      required int bodyTemperature,
      required int pulse,
      required int spo,
      required String airQuality}) {

    if(LiveData.shared.context!=null){
      if (humidity < 30) {
        humidityFlag = true;
        showParameterAlert(LiveData.shared.context!, "Warning - Low Humidity", "Ashika Helmet: 2196 environment has been detected with low humidity:"+humidity.toString());
      }else{
        humidityFlag = false;
      }


      if (roomTemperature > 40) {
        roomTemperatureFlag = true;
        showParameterAlert(LiveData.shared.context!, "Warning - High Room Temperature", "Ashika Helmet: 2196 environment has been detected with high room temperature:"+roomTemperature.toString());
      }else{
        roomTemperatureFlag = false;
      }


      if (bodyTemperature > 38 || bodyTemperature < 36) {
        temperatureFlag = true;
        showParameterAlert(LiveData.shared.context!, "Warning - Abnormal Body Temperature", "Ashika Helmet: 2196 has been detected with abnormal body temperature:"+bodyTemperature.toString());
      }else{
        temperatureFlag = false;
      }


      if (pulse > 120 || pulse < 40) {
        pulseFlag = true;
        showParameterAlert(LiveData.shared.context!, "Warning - Abnormal Pulse Rate", "Ashika Helmet: 2196 has been detected with abnormal pulse rate:"+pulse.toString());
      }else{
        pulseFlag = false;
      }


      if (spo < 90) {
        spoFlag = true;
        showParameterAlert(LiveData.shared.context!, "Warning - Low Blood Oxygen Level", "Ashika Helmet: 2196 has been detected with low blood oxygen level:"+spo.toString());
      }else{
        spoFlag = false;
      }

      if(airQuality=='BAD'){
        showParameterAlert(LiveData.shared.context!, "Warning - BAD Air Quality", "Ashika Helmet: 2196 has been detected with BAD Air Quality");
      }
    }
  }

  void detectFall(int fallData) {
    if (fallData == 1 && previousState != fallData && LiveData.shared.context != null) {
      Navigator.of(LiveData.shared.context!, rootNavigator: true)
          .push(CupertinoPageRoute(builder: (BuildContext context) => const GeolocatorWidget()));
    }
    else if (fallData == 0 && previousState != fallData && LiveData.shared.context != null) {
        if(pageState == 1){
          Navigator.of(LiveData.shared.context!, rootNavigator: true)
              .push(CupertinoPageRoute(builder: (BuildContext context) => const HomeScreen()));
        }else if(pageState == 2){
          Navigator.of(LiveData.shared.context!, rootNavigator: true)
              .push(CupertinoPageRoute(builder: (BuildContext context) => const HostScreen()));
        }
    }
  }

  void dispose() {
    liveDataTimer?.cancel();
  }
}
