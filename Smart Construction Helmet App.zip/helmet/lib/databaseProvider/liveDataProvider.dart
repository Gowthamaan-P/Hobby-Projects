import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class LiveDataProvider {
  static const url = "https://script.google.com/macros/s/AKfycbzacxUzkDMDbRWyJPrg2eYH-ZwMxaiayuBfRaVB8bDxiw0U8Ocy/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<LiveHelmetData>> getLiveMeterData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => LiveHelmetData.fromJson(json)).toList();
    });
  }
}

class LiveHelmetData {

  String? temperature;
  String? humidity;
  String? bodyTemperature;
  String mqtRaw;
  String airQuality;
  String? pulse;
  String? spO2;
  String? fallDetection;
  String dayDetection;
  String ledStatus;
  String findHelmet;
  String status;
  String timestamp;

  LiveHelmetData({
    required this.temperature,
    required this.humidity,
    required this.bodyTemperature,
    required this.mqtRaw,
    required this.airQuality,
    required this.pulse,
    required this.spO2,
    required this.fallDetection,
    required this.dayDetection,
    required this.ledStatus,
    required this.findHelmet,
    required this.status,
    required this.timestamp
  });

  factory LiveHelmetData.fromJson(dynamic json) {
    return LiveHelmetData(
        temperature: "${json['temperature']}",
        humidity: "${json['humidity']}",
        bodyTemperature: "${json['bodyTemperature']}",
        mqtRaw: "${json['mqtRaw']}",
        airQuality: "${json['airQuality']}",
        pulse: "${json['pulse']}",
        spO2: "${json['spO2']}",
        fallDetection: "${json['fallDetection']}",
        dayDetection: "${json['dayDetection']}",
        ledStatus: "${json['ledStatus']}",
        findHelmet: "${json['findHelmet']}",
        status: "${json['status']}",
        timestamp: "${json['timestamp']}"
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
        'temperature': temperature,
        'humidity': humidity,
        'bodyTemperature': bodyTemperature,
        'mqtRaw': mqtRaw,
        'airQuality': airQuality,
        'pulse': pulse,
        'spO2': spO2,
        'fallDetection': fallDetection,
        'dayDetection': dayDetection,
        'ledStatus': ledStatus,
        'findHelmet': findHelmet,
        'status': status,
        'timestamp': timestamp
      };
}
