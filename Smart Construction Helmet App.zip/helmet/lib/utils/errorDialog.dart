import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

showIncorrectCredentials(BuildContext context) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          dialogWidth: 450,
          title: Column(
            children: const [
              Icon(Icons.error_outline_rounded,
                  size: 60, color: Color(0XFFB71C1C)),
              Text(
                "Incorrect Credentials",
                style: TextStyle(
                    fontSize: 25,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: const Padding(
            padding: EdgeInsets.symmetric(vertical: 10.0),
            child: Text(
              "Please verify your login credentials and try login in again",
              style: TextStyle(fontSize: 20, letterSpacing: 1),
            ),
          ),
          actions: <Widget>[
            CupertinoDialogAction(
              child: const Text(
                "Close",
                style: TextStyle(fontSize: 20, letterSpacing: 1),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
}

showFallIndication(BuildContext context) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          dialogWidth: 450,
          title: Column(
            children: const [
              Icon(Icons.emergency,
                  size: 60, color: Color(0XFFB71C1C)),
              Text(
                "Fall Detected - Ashika Helmet: 2196",
                style: TextStyle(
                    fontSize: 25,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: const Padding(
            padding: EdgeInsets.symmetric(vertical: 10.0),
            child: Text(
              "Emergency alert. Worker fell down or impact detected",
              style: TextStyle(fontSize: 20, letterSpacing: 1),
            ),
          ),
          actions: <Widget>[
            CupertinoDialogAction(
              child: const Text(
                "Close",
                style: TextStyle(fontSize: 20, letterSpacing: 1),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
}

showParameterAlert(BuildContext context, String heading, String message) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          dialogWidth: 450,
          title: Column(
            children:  [
              const Icon(Icons.error_outline_rounded,
                  size: 60, color: Color(0XFFB71C1C)),
              Text(
                heading,
                style: TextStyle(
                    fontSize: 25,
                    letterSpacing: 1,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content:  Padding(
            padding: const EdgeInsets.symmetric(vertical: 10.0),
            child: Text(
              message,
              style: const TextStyle(fontSize: 20, letterSpacing: 1),
            ),
          ),
          actions: <Widget>[
            CupertinoDialogAction(
              child: const Text(
                "Close",
                style: TextStyle(fontSize: 20, letterSpacing: 1),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      });
}