import 'package:flutter/material.dart';
import 'package:helmet/utils/const.dart';
import 'package:helmet/widgets/custom_clipper.dart';

class CardSection extends StatelessWidget {
  final String title;
  final String value;
  final String unit;
  final String time;
  final Icon icon;
  final bool? isDone;

  const CardSection(
      {Key? key,
      required this.title,
      required this.value,
      required this.unit,
      required this.time,
      required this.icon,
      this.isDone})
      : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Align(
        alignment: Alignment.center,
        child: Container(
            margin: const EdgeInsets.only(right: 15.0),
            width: 300,
            height: 205,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(10.0)),
              shape: BoxShape.rectangle,
              color: Colors.white,
            ),
            child: Stack(
              clipBehavior: Clip.hardEdge, children: <Widget>[
                Positioned(
                    child: ClipPath(
                        clipper: MyCustomClipper(clipType: ClipType.semiCircle),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.all(Radius.circular(10.0)),
                            color: Constants.lightBlue.withOpacity(0.1),
                          ),
                          height: 120,
                          width: 120,
                        ),
                    ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          icon,
                          Text(
                              time,
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Constants.textPrimary
                              ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(title,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize: 40,
                                        fontWeight: FontWeight.bold,
                                        color: Constants.textPrimary
                                    ),
                                ),
                                const SizedBox(height: 5),
                                Text('$value $unit',
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Constants.textPrimary
                                    ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10)
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
        ),
    );
  }
}
