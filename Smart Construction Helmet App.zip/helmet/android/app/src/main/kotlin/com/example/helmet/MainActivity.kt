package com.example.helmet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
