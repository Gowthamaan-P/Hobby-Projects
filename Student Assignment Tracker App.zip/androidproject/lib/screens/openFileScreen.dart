import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:google_fonts/google_fonts.dart';


class ViewPickedFile extends StatefulWidget {
  final url;

  ViewPickedFile(this.url);

  @override
  createState() => _ViewPickedFileState(this.url);
}

class _ViewPickedFileState extends State<ViewPickedFile> {
  var _url;


  _ViewPickedFileState(this._url);

  InAppWebViewController? webView;
  int _stackToView = 1;

  void _handleLoad() {
    setState(() {
      _stackToView = 0;
    });
  }

  late PullToRefreshController pullToRefreshController;

  InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));

  Widget _title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'GE',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Colors.cyan,
          ),
          children: [
            TextSpan(
              text: 'note',
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
            TextSpan(
              text: 'z',
              style: TextStyle(color: Colors.cyan, fontSize: 30),
            ),
          ]),
    );
  }

  @override
  void initState() {
    print("$_url");
    pullToRefreshController = PullToRefreshController(
      options: PullToRefreshOptions(
        color: Colors.blue,
      ),
      onRefresh: () async {
        if (Platform.isAndroid) {
          webView?.reload();
        } else if (Platform.isIOS) {
          webView?.loadUrl(
              urlRequest: URLRequest(url: await webView?.getUrl()));
        }
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.1,
          backgroundColor: Color.fromRGBO(58, 66, 86, 1.0),
          title: _title(),
        ),
        body: IndexedStack(
          index: _stackToView,
          children: [
            Column(
              children: <Widget>[
                Expanded(
                    child: InAppWebView(
                      initialUrlRequest: URLRequest(url: Uri.parse(_url)),
                      initialOptions: options,
                      pullToRefreshController: pullToRefreshController,
                      onWebViewCreated: (InAppWebViewController controller) {
                        webView = controller;
                      },
                      onLoadStart: (controller, url) {
                      },
                      onLoadStop: (controller, url) async {
                        pullToRefreshController.endRefreshing();
                        _handleLoad();
                      },
                      onLoadError: (controller, url, code, message) {
                        pullToRefreshController.endRefreshing();
                      },
                    ))
              ],
            ),
            Container(
                child: Center(
              child: CircularProgressIndicator(),
            )),
          ],
        ));
  }
}
