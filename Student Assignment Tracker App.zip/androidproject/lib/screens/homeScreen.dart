import 'package:androidproject/helpers/utilityFunctions.dart';
import 'package:androidproject/screens/listFilesScreen.dart';
import 'package:androidproject/screens/loginScreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  Widget _title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'GE',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Colors.cyan,
          ),
          children: [
            TextSpan(
              text: 'note',
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
            TextSpan(
              text: 'z',
              style: TextStyle(color: Colors.cyan, fontSize: 30),
            ),
          ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async=> false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0.1,
          backgroundColor: Color.fromRGBO(58, 66, 86, 1.0),
          title: _title(),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.exit_to_app_rounded),
              onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
              },
            )
          ],
        ),
        backgroundColor: Color.fromRGBO(58, 66, 86, 1.0),
        body: Container(
          child:  ListView.builder(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemCount: subjects.length,
            itemBuilder: (BuildContext context, int index) {
              return Card(
                elevation: 8.0,
                margin: new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Color.fromRGBO(64, 75, 96, .9)),
                  child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                      leading: Container(
                        padding: EdgeInsets.only(right: 12.0),
                        decoration: new BoxDecoration(
                            border: new Border(
                                right: new BorderSide(width: 1.0, color: Colors.white24))),
                        child: Text(
                          "${subjectsIcons[index]}",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(
                        "${subjects[index]}",
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                      trailing: GestureDetector(
                          child: Icon(Icons.keyboard_arrow_right,
                          color: Colors.white,
                          size: 30.0),
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => ListFilesScreen(subjectName: subjects[index],)));
                        },
                      )
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
