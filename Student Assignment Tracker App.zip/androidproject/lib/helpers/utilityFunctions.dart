import 'package:androidproject/models/driveFilesHandler.dart';

List<DriveFilesObject> filesList = [];
final List<String> subjects = ["Communication English", "Computer Programming", "Engineering Chemistry",
"Engineering Graphics", "Engineering Physics", "GIP", "IS", "M1", "M2", "MPMC", "OOPL", "PT"];

final List<String> subjectsIcons = ["CE", "CP", "EC", "EG", "EP","GI", "IS", "M1", "M2", "MP", "OO", "PT"];


List<List<String>> fileLinks = List.generate(12, (index) => []);

void getFilesList()async{
  filesList = await DriveFilesHandler().getItemList();
  filesList.removeLast();
}




