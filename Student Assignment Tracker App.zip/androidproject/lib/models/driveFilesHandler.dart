import 'dart:convert' as convert;

import 'package:http/http.dart' as http;



class DriveFilesHandler {

  static const String URL =
      "https://script.google.com/macros/s/AKfycbzWw-HH8gYKDDuwS_2chiXZU-3DBL9LezhQ6cWNxc6ibaE4NwM/exec";

  static const STATUS_SUCCESS = "SUCCESS";

  void submitForm(
      DriveFilesObject registrationForm, void Function(String) callback) async {
    try {
      await http.post(Uri.parse(URL), body: registrationForm.toJson()).then((response) async {
        print("${response.body}");
        if (response.statusCode == 302) {
          String url = response.headers['location']?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status']);
          });
        } else {
          callback(convert.jsonDecode(response.body)['status']);
        }
      });
    } catch (e) {
      print("Error $e");
    }
  }


  Future<List<DriveFilesObject>> getItemList() async {
    return await http.get(Uri.parse(URL)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => DriveFilesObject.fromJson(json)).toList();
    });
  }
}

///Inward Form model
class DriveFilesObject {

  String subject;
  String fileName;
  String fileType;
  String link;

  DriveFilesObject(this.subject, this.fileName, this.fileType, this.link);

  factory DriveFilesObject.fromJson(dynamic json) {
    return DriveFilesObject(
        "${json['subject']}",
        "${json['fileName']}",
        "${json['fileType']}",
        "${json['link']}"
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
    'subject': subject,
    'fileName': fileName,
    'fileType': fileType,
    'link': link
  };
}