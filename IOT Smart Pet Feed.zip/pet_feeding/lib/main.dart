import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pet_feeding/src/screens/splashScreen.dart';


void main() {
  runApp(const Peace());
}

class Peace extends StatelessWidget {
  const Peace({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.firaSansCondensedTextTheme(Theme.of(context).textTheme),
          visualDensity: VisualDensity.adaptivePlatformDensity,
          primaryColor: Colors.blue.shade800),
      home: const SplashScreen(), //SplashScreen
    );
  }
}