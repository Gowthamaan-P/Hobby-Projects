import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pet_feeding/src/dataProviders/controlDataManager.dart';
import 'package:pet_feeding/src/helpers/applicationStateManager.dart';
import 'package:pet_feeding/src/screens/appStateManager.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  startTime() async {
    var _duration = const Duration(seconds: 3);
    ApplicationStateVariables.shared.currentControlParameters = (await FeedingControlDataProvider().getItemsList())[0];
    return Timer(_duration, navigationPage);
  }

  void navigationPage() {
    if(mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => const AppStateManager()));
    }
  }

  @override
  void initState() {
    super.initState();
    ApplicationStateVariables.shared.initiateSystem();
    startTime();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitDown,
      DeviceOrientation.portraitUp,
    ]);

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky, overlays: []);

    return Scaffold(
      backgroundColor: Colors.lightBlue.shade900,
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 130,
              width: 130,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
                  image: DecorationImage(
                      fit: BoxFit.fill,
                      image: AssetImage(
                        "assets/images/logo.jpg",
                      ))),
            ),
            const SizedBox(height: 50),
            const Text(
              "Smart Pet Feeder",
              style: TextStyle(
                  fontSize: 42,
                  color: Colors.white,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
