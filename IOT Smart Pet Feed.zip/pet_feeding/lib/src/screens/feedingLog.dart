import 'package:adaptivex/adaptivex.dart';
import 'package:flutter/material.dart';
import 'package:pet_feeding/src/dataProviders/feedingLogProvider.dart';
import 'package:pet_feeding/src/helpers/responsiveTable/dataTableHeader.dart';
import 'package:pet_feeding/src/helpers/responsiveTable/responsiveDataTable.dart';

class ViewFeedingLog extends StatefulWidget {
  const ViewFeedingLog({Key? key}) : super(key: key);

  @override
  _ViewFeedingLogState createState() => _ViewFeedingLogState();
}

class _ViewFeedingLogState extends State<ViewFeedingLog> {

  final List<DatatableHeader> _headers = [
    DatatableHeader(
        text: "PET ID",
        value: "petId",
        flex: 1,
        show: true,
        sortable: false,
        textAlign: TextAlign.center),
    DatatableHeader(
        text: "QUANTITY",
        value: "quantity",
        flex: 1,
        show: true,
        sortable: false,
        textAlign: TextAlign.center),
    DatatableHeader(
        text: "TIMESTAMP",
        value: "timeStamp",
        flex: 2,
        show: true,
        sortable: false,
        textAlign: TextAlign.center)
  ];

  final List<int> _perPages = [10, 20, 50, 100];
  int _total = 100;
  int? _currentPerPage = 10;
  List<bool>? _expanded;
  String? _searchKey = "id";

  int _currentPage = 1;
  bool _isSearch = false;
  final List<Map<String, dynamic>> _sourceOriginal = [];
  List<Map<String, dynamic>> _sourceFiltered = [];
  List<Map<String, dynamic>> _source = [];
  List<Map<String, dynamic>> _selecteds = [];

  String? _sortColumn;
  bool _sortAscending = true;
  bool _isLoading = false;
  final bool _showSelect = false;

  Future<List<Map<String, dynamic>>> _generateData() async{
    final List<FeedingLog> feedingLog = await FeedingLogProvider().getItemsList();

    List<Map<String, dynamic>> temps = [];
    for (var element in feedingLog) {
      temps.add({
        'timeStamp': element.timeStamp,
        'petId': element.petId,
        'quantity': element.quantity
      });
    }
    return temps;
  }

  _initializeData() async {
    if(mounted){
      setState(() => _isLoading = true);
    }
    Future.delayed(const Duration(milliseconds: 200)).then((value) async{
      _sourceOriginal.clear();
      _sourceOriginal.addAll(await _generateData());
      _sourceFiltered = _sourceOriginal;
      _total = _sourceFiltered.length;
      int value = (_total > (_currentPerPage??0))? _currentPerPage!:_sourceFiltered.length;
      _expanded = List.generate(_currentPerPage!, (index) => false);
      _source = _sourceFiltered.getRange(0, value).toList();
      if(mounted){
        setState(() => _isLoading = false);
      }
    });
  }

  _resetData({start = 0}) async {
    if(mounted){
      setState(() => _isLoading = true);
    }
    var _expandedLen =
    _total - start < _currentPerPage! ? _total - start : _currentPerPage;
    Future.delayed(const Duration(seconds: 0)).then((value) {
      _expanded = List.generate(_expandedLen as int, (index) => false);
      _source.clear();
      _source = _sourceFiltered.getRange(start, start + _expandedLen).toList();
      if(mounted){
        setState(() => _isLoading = false);
      }
    });
  }

  _filterData(value) {

    if(mounted){
      setState(() => _isLoading = true);
    }

    try {
      if (value == "" || value == null) {
        _sourceFiltered = _sourceOriginal;
      } else {
        _sourceFiltered = _sourceOriginal
            .where((data) => data[_searchKey!]
            .toString()
            .toLowerCase()
            .contains(value.toString().toLowerCase()))
            .toList();
      }

      _total = _sourceFiltered.length;
      var _rangeTop = _total < _currentPerPage! ? _total : _currentPerPage!;
      _expanded = List.generate(_rangeTop, (index) => false);
      _source = _sourceFiltered.getRange(0, _rangeTop).toList();
    } catch (e) {
      debugPrint("$e");
    }
    if(mounted){
      setState(() => _isLoading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height - 90;
    final width = MediaQuery.of(context).size.width - 30;

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.start,
          children:  [
            Row(
              children: [
                IconButton(
                    onPressed: (){
                      try {
                        Navigator.pop(context);
                      } catch (e) {
                        debugPrint(e.toString());
                      }
                    },
                    icon: const Icon(Icons.chevron_left_rounded),
                    padding: EdgeInsets.zero
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 5.0),
                  child: Text("Feeding Log",
                      style: TextStyle(
                          fontSize: 20,
                          height: 1,
                          color: Color(0XFF3C4958),
                          fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            SizedBox(
                height: height,
                width: width,
                child: Card(
                  elevation: 1,
                  shadowColor: Colors.black,
                  clipBehavior: Clip.none,
                  margin: EdgeInsets.zero,
                  child: ResponsiveDatatable(
                    responseScreenSizes: const [ScreenSize.xs],
                    actions: [
                      if (_isSearch)
                        Expanded(
                            child: TextField(
                              decoration: InputDecoration(
                                  hintText: 'Enter search term based on ' +
                                      _searchKey!
                                          .replaceAll(RegExp('[\\W_]+'), ' ')
                                          .toUpperCase(),
                                  prefixIcon: IconButton(
                                      icon: const Icon(Icons.cancel),
                                      onPressed: () {
                                        if(mounted){
                                          setState(() {
                                            _isSearch = false;
                                          });
                                        }
                                        _initializeData();
                                      }),
                                  suffixIcon: IconButton(
                                      icon: const Icon(Icons.search),
                                      onPressed: () {})),
                              onSubmitted: (value) {
                                _filterData(value);
                              },
                            )),
                      if (!_isSearch)
                        IconButton(
                            icon: const Icon(Icons.search),
                            onPressed: () {
                              if(mounted){
                                setState(() {
                                  _isSearch = true;
                                });
                              }
                            })
                    ],
                    headers: _headers,
                    source: _source,
                    selecteds: _selecteds,
                    showSelect: _showSelect,
                    autoHeight: false,
                    isExpandRows: false,
                    onChangedRow: (value, header) {},
                    onSubmittedRow: (value, header) {},
                    onTabRow: (data) {},
                    onSort: (value) {
                      if(mounted){
                        setState(() => _isLoading = true);
                        setState(() {
                          _sortColumn = value;
                          _sortAscending = !_sortAscending;
                          if (_sortAscending) {
                            _sourceFiltered.sort((a, b) =>
                                b["$_sortColumn"].compareTo(a["$_sortColumn"]));
                          } else {
                            _sourceFiltered.sort((a, b) =>
                                a["$_sortColumn"].compareTo(b["$_sortColumn"]));
                          }
                          var _rangeTop = _currentPerPage! < _sourceFiltered.length
                              ? _currentPerPage!
                              : _sourceFiltered.length;
                          _source = _sourceFiltered.getRange(0, _rangeTop).toList();
                          _searchKey = value;

                          _isLoading = false;
                        });
                      }
                    },
                    expanded: _expanded,
                    sortAscending: _sortAscending,
                    sortColumn: _sortColumn,
                    isLoading: _isLoading,
                    onSelect: (value, item) {
                      if(mounted){
                        if (value!) {
                          setState(() => _selecteds.add(item));
                        } else {
                          setState(
                                  () => _selecteds.removeAt(_selecteds.indexOf(item)));
                        }
                      }
                    },
                    onSelectAll: (value) {
                      if(mounted){
                        if (value!) {
                          setState(() => _selecteds =
                              _source.map((entry) => entry).toList().cast());
                        } else {
                          setState(() => _selecteds.clear());
                        }
                      }
                    },
                    footers: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: const Text("Rows per page:"),
                      ),
                      if (_perPages.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: DropdownButton<int>(
                            value: _currentPerPage,
                            items: _perPages
                                .map((e) => DropdownMenuItem<int>(
                              child: Text("$e"),
                              value: e,
                            ))
                                .toList(),
                            onChanged: (dynamic value) {
                              setState(() {
                                _currentPerPage = value;
                                _currentPage = 1;
                                _resetData();
                              });
                            },
                            isExpanded: false,
                          ),
                        ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: Text("$_currentPage - $_currentPerPage of $_total"),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.arrow_back_ios,
                          size: 16,
                        ),
                        onPressed: _currentPage == 1
                            ? null
                            : () {
                          var _nextSet = _currentPage - _currentPerPage!;
                          setState(() {
                            _currentPage = _nextSet > 1 ? _nextSet : 1;
                            _resetData(start: _currentPage - 1);
                          });
                        },
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_forward_ios, size: 16),
                        onPressed: _currentPage + _currentPerPage! - 1 > _total
                            ? null
                            : () {
                          var _nextSet = _currentPage + _currentPerPage!;

                          setState(() {
                            _currentPage = _nextSet < _total
                                ? _nextSet
                                : _total - _currentPerPage!;
                            _resetData(start: _nextSet - 1);
                          });
                        },
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                      )
                    ],
                    headerDecoration: const BoxDecoration(color: Color(0xFFBBDEFB)),
                    headerTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    rowTextStyle: const TextStyle(color: Colors.black),
                    selectedTextStyle: const TextStyle(color: Colors.white),
                  ),
                )
            ),
          ],
        ),
      ),
    );
  }

}
