import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_bloc/flutter_form_bloc.dart';
import 'package:pet_feeding/src/dataProviders/controlDataManager.dart';
import 'package:pet_feeding/src/helpers/applicationStateManager.dart';
import 'package:pet_feeding/src/screens/feedingLog.dart';
import 'package:pet_feeding/src/screens/loadingScreen.dart';

class FeederForm extends FormBloc<String, String> {
  final quantityOne = TextFieldBloc(validators: [FieldBlocValidators.required]);
  final quantityTwo = TextFieldBloc(validators: [FieldBlocValidators.required]);
  final timeOne = InputFieldBloc<TimeOfDay?, Object>(
      initialValue: null, validators: [FieldBlocValidators.required]);
  final timeTwo = InputFieldBloc<TimeOfDay?, Object>(
      initialValue: null, validators: [FieldBlocValidators.required]);

  FeederForm() {
    addFieldBlocs(fieldBlocs: [quantityOne, quantityTwo, timeOne, timeTwo]);
  }

  @override
  void onSubmitting() async {
    FeedingControl controlParameters = FeedingControl(
        quantityOne: quantityOne.value,
        quantityTwo: quantityTwo.value,
        timeOne: getTime(timeOne),
        timeTwo: getTime(timeTwo),
        emptyAlert: ApplicationStateVariables.shared.currentControlParameters!.emptyAlert);

    debugPrint(controlParameters.toJson().toString());

    FeedingControlDataProvider().editControlData(controlParameters, (String status) {
      if(FeedingControlDataProvider.statusSuccess == status){
        emitSuccess();
      }else{
        emitFailure();
      }
    });
  }

  @override
  void onLoading() async {}

  String getTime(InputFieldBloc<TimeOfDay?, Object> timeBloc){
    int hour  = (timeBloc.value?.hour)??0;
    int minutes  = (timeBloc.value?.minute)??0;
    return '${hour}:$minutes';
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isValuesInitiated = false;

  @override
  void initState() {
    isValuesInitiated = false;
    super.initState();
    ApplicationStateVariables.shared.periodicControlDataTimer();
  }

  @override
  void dispose() {
    ApplicationStateVariables.shared.disposeData();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky, overlays: []);
    ApplicationStateVariables.shared.viewPortContext = context;

    return WillPopScope(
      onWillPop: () async => false,
      child: BlocProvider(
        create: (context) => FeederForm(),
        child: Builder(
          builder: (context) {
            final formBloc = BlocProvider.of<FeederForm>(context);

            if (ApplicationStateVariables.shared.currentControlParameters != null && !isValuesInitiated) {
              formBloc.quantityOne.updateInitialValue(ApplicationStateVariables
                  .shared.currentControlParameters!.quantityOne);
              formBloc.quantityTwo.updateInitialValue(ApplicationStateVariables
                  .shared.currentControlParameters!.quantityOne);
              formBloc.timeOne.updateInitialValue(TimeOfDay(
                  hour: int.parse(ApplicationStateVariables
                      .shared.currentControlParameters!.timeOne
                      .split(':')[0]),
                  minute: int.parse(ApplicationStateVariables
                      .shared.currentControlParameters!.timeOne
                      .split(':')[1])));
              formBloc.timeTwo.updateInitialValue(TimeOfDay(
                  hour: int.parse(ApplicationStateVariables
                      .shared.currentControlParameters!.timeTwo
                      .split(':')[0]),
                  minute: int.parse(ApplicationStateVariables
                      .shared.currentControlParameters!.timeTwo
                      .split(':')[1])));
            }

            return Theme(
              data: Theme.of(context).copyWith(
                inputDecorationTheme: InputDecorationTheme(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              child: FormBlocListener<FeederForm, String, String>(
                onSubmitting: (context, state){
                  OverlayLoader.show(context);
                },
                onSuccess: (context, state){
                  OverlayLoader.hide(context);
                },
                onFailure: (context, state){
                  OverlayLoader.hide(context);
                },
                child: Scaffold(
                  backgroundColor: Colors.grey.shade200,
                  body: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Card(
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10))),
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Food Quantity",
                                    style: TextStyle(
                                        fontSize: 30,
                                        color: Colors.blue,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: TextFieldBlocBuilder(
                                      textFieldBloc: formBloc.quantityOne,
                                      isEnabled: true,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                        labelText: 'Quantity - 1',
                                        prefixIcon: Icon(Icons.food_bank_outlined),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: TextFieldBlocBuilder(
                                      textFieldBloc: formBloc.quantityTwo,
                                      isEnabled: true,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                        labelText: 'Quantity - 2',
                                        prefixIcon: Icon(Icons.food_bank_outlined),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Card(
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10))),
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Time",
                                    style: TextStyle(
                                        fontSize: 30,
                                        color: Colors.blue,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: TimeFieldBlocBuilder(
                                      timeFieldBloc: formBloc.timeOne,
                                      format: DateFormat('hh:mm a'),
                                      initialTime: TimeOfDay.now(),
                                      decoration: const InputDecoration(
                                        labelText: 'Time - 1',
                                        prefixIcon: Icon(Icons.access_time),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: TimeFieldBlocBuilder(
                                      timeFieldBloc: formBloc.timeTwo,
                                      format: DateFormat('hh:mm a'),
                                      initialTime: TimeOfDay.now(),
                                      decoration: const InputDecoration(
                                        labelText: 'Time - 2',
                                        prefixIcon: Icon(Icons.access_time),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          MaterialButton(
                            onPressed: ()=> formBloc.submit(),
                            padding: const EdgeInsets.all(15.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(15)),
                            ),
                            color: Colors.amber,
                            child: const Text(
                              'Save Control Changes',
                              style: TextStyle(
                                color: Colors.black,
                                letterSpacing: 1.5,
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: MaterialButton(
                              onPressed: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) => const ViewFeedingLog()));
                              },
                              padding: const EdgeInsets.all(15.0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(15)),
                              ),
                              color: Colors.blue.shade900,
                              child: const Text(
                                'View Pet Feeding Log',
                                style: TextStyle(
                                  color: Colors.white,
                                  letterSpacing: 1.5,
                                  fontSize: 18.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
