import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:pet_feeding/src/screens/homeScreen.dart';
import 'package:pet_feeding/src/screens/no_internetConnection_screen.dart';
import 'package:pet_feeding/src/screens/splashScreen.dart';


class AppStateManager extends StatelessWidget {
  const AppStateManager({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: InternetConnectionChecker().onStatusChange,
        builder: (BuildContext context, snapshot) {
          if(snapshot.data==null) {
            return const SplashScreen();
          }
          else if(snapshot.data == InternetConnectionStatus.connected) {
            return const HomeScreen();
          }
          return const NoInternetConnection();
        });
  }
}