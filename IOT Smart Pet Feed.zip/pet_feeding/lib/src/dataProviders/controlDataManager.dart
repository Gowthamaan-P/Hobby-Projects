import 'dart:convert' as convert;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class FeedingControlDataProvider {
  static const String url =
      "https://script.google.com/macros/s/AKfycbxyxTrvv60pcclv9wqB05wj94721ns6-_PUx3fYMw/exec";

  static const statusSuccess = "SUCCESS";

  void editControlData(FeedingControl product, void Function(String) callback) async {
    try {
      await http
          .post(Uri.parse(url), body: product.toJson())
          .then((response) async {
        if (response.statusCode == 302) {
          String url = response.headers['location'] ?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status']);
          });
        } else {
          callback(convert.jsonDecode(response.body)['status']);
        }
      });
    } catch (e) {
      debugPrint("Error $e");
    }
  }

  Future<List<FeedingControl>> getItemsList() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => FeedingControl.fromJson(json)).toList();
    });
  }
}

class FeedingControl {
  String quantityOne;
  String quantityTwo;
  String timeOne;
  String timeTwo;
  String emptyAlert;

  FeedingControl(
      {required this.quantityOne,
      required this.quantityTwo,
      required this.timeOne,
      required this.timeTwo,
      required this.emptyAlert});

  factory FeedingControl.fromJson(dynamic json) {
    return FeedingControl(
        quantityOne: "${json['quantityOne']}",
        quantityTwo: "${json['quantityTwo']}",
        timeTwo: "${json['timeTwo']}",
        emptyAlert: "${json['emptyAlert']}",
        timeOne: "${json['timeOne']}");
  }

  Map toJson() => {
        'quantityOne': quantityOne,
        'quantityTwo': quantityTwo,
        'emptyAlert': emptyAlert,
        'timeTwo': timeTwo,
        'timeOne': timeOne
      };
}
