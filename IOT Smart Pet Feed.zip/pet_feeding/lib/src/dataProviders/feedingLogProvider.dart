import 'dart:convert' as convert;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class FeedingLogProvider {
  static const String url = "https://script.google.com/macros/s/AKfycbw_wePLW2G161UnNDPQrBOLiiReoAvnBZ5azHwYIg/exec";

  static const statusSuccess = "SUCCESS";

  void addLog(FeedingLog product, void Function(String) callback) async {
    try {
      await http.post(Uri.parse(url), body: product.toJson()).then((response) async {
        if (response.statusCode == 302) {
          String url = response.headers['location'] ?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status']);
          });
        }
        else {
          callback(convert.jsonDecode(response.body)['status']);
        }
      });
    } catch (e) {
      debugPrint("Error $e");
    }
  }

  Future<List<FeedingLog>> getItemsList() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => FeedingLog.fromJson(json)).toList();
    });
  }
}

class FeedingLog {
  String petId;
  String quantity;
  String timeStamp;

  FeedingLog({required this.petId, required this.quantity, required this.timeStamp});

  factory FeedingLog.fromJson(dynamic json) {
    return FeedingLog(petId: "${json['petId']}", quantity: "${json['quantity']}", timeStamp: "${json['timeStamp']}");
  }

  Map toJson() => {'petId': petId, 'quantity': quantity, 'timeStamp': timeStamp};
}


