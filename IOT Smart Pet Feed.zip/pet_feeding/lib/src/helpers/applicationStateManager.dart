import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pet_feeding/src/dataProviders/controlDataManager.dart';

class ApplicationStateVariables{
  static final ApplicationStateVariables _singleton = ApplicationStateVariables._internal();
  static ApplicationStateVariables get shared => _singleton;
  factory ApplicationStateVariables() => _singleton;
  ApplicationStateVariables._internal();

  FeedingControl? currentControlParameters;
  BuildContext? viewPortContext;
  Timer? controlDataTimer;
  bool? isFoodEmpty;


  void initiateSystem()async{
    currentControlParameters = (await FeedingControlDataProvider().getItemsList())[0];
  }

  void periodicControlDataTimer()async{
    controlDataTimer = Timer.periodic(Duration(seconds: 3), (timer) async {
      currentControlParameters = (await FeedingControlDataProvider().getItemsList())[0];

      if((currentControlParameters?.emptyAlert??'0')=='1'  &&  !(isFoodEmpty?? false)){
        if(viewPortContext!=null){
          isFoodEmpty = true;
          showFoodEmptyDialog(viewPortContext!);
        }
      }
      else if((currentControlParameters?.emptyAlert??'0')=='0'  &&  (isFoodEmpty?? false)){
        if(viewPortContext!=null){
          isFoodEmpty = false;
          Navigator.pop(viewPortContext!);
        }

      }
    });
  }

  void disposeData(){
    controlDataTimer?.cancel();
  }

  showFoodEmptyDialog(BuildContext context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return CupertinoAlertDialog(
            title: Column(
              children: const [
                Icon(Icons.error_outline_outlined, size: 60, color: Colors.red),
                Text(
                  "Empty Alert",
                  style: TextStyle(
                      fontSize: 25, letterSpacing: 1, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            content: const Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0),
              child: Text(
                "Pet Food storage is empty. Please fill immediately",
                style: TextStyle(fontSize: 20, letterSpacing: 1),
              ),
            ),
            actions: <Widget>[ ],
          );
        });
  }
}