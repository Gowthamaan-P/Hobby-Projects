import 'package:energy/screens/homePage.dart';
import 'package:energy/screens/splashScreen.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';


class AppStateManager extends StatelessWidget {
  const AppStateManager({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: InternetConnectionChecker().onStatusChange,
        builder: (BuildContext context, snapshot) {
          if(snapshot.data==null) {
            return const SplashScreen();
          }
          else if(snapshot.data == InternetConnectionStatus.connected) {
            return const HomePage();
          }
          return const NoInternetConnection();
        });
  }
}



class NoInternetConnection extends StatelessWidget {
  const NoInternetConnection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: const <Widget>[
          Text(
            "Oops...",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize:  40,
                color: Color(0XFF01579B),
                fontWeight: FontWeight.bold
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 20.0),
            child: Icon(Icons.signal_wifi_connected_no_internet_4, size: 60, color: Color(0XFFD50000)),
          ),
          Text(
            "Slow or No Internet Connection",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize:  20,
                fontWeight: FontWeight.bold
            ),
          ),
          Padding(
            padding: EdgeInsets.all(25.0),
            child: Text(
              "You are not connected to the internet. Make sure Wi-Fi/Data is on, Airplane mode is off and try again.",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 18,
                  color: Color(0XFF01579B),
                  fontWeight: FontWeight.bold
              ),
            ),
          ),
        ],
      ),
    );
  }
}