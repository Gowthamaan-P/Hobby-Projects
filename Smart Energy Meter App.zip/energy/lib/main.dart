import 'package:energy/screens/splashScreen.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(const SmartEnergyMeter());
}

class SmartEnergyMeter extends StatelessWidget {
  const SmartEnergyMeter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          fontFamily: "FiraSans",
          visualDensity: VisualDensity.adaptivePlatformDensity,
          primaryColor: Colors.blue.shade800),
      home: const SplashScreen(), //SplashScreen
    );
  }
}
