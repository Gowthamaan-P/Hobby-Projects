import 'dart:async';

import 'package:energy/core/liveDataProvider.dart';
import 'package:energy/core/models.dart';

class DataHandler{

  static final DataHandler _singleton = DataHandler._internal();
  static DataHandler get shared => _singleton;
  factory DataHandler() => _singleton;
  DataHandler._internal();

  Timer? liveDataTimer;

  void liveDataProvider(){
    liveDataTimer = Timer.periodic(const Duration(seconds: 10), (timer)async{
      List<LiveMeterData> liveData = await LiveDataProvider().getLiveMeterData();
      if(liveData.isNotEmpty){
        LiveMeterData meterData = liveData.last;
        LiveData.shared.voltage = meterData.voltage;
        LiveData.shared.current = meterData.current;
        LiveData.shared.power = meterData.power;
        LiveData.shared.energy = meterData.energy;
        LiveData.shared.frequency = meterData.frequency;
        LiveData.shared.powerFactor = meterData.powerFactor;
        LiveData.shared.timeStamp = meterData.timeStamp;
        LiveData.shared.currentLiveDataDisplay!.rebuildLiveDataDisplay();
      }
    });
  }

  void dispose(){
    liveDataTimer?.cancel();
  }
}