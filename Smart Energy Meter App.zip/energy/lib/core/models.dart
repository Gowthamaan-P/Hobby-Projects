import 'package:flutter/cupertino.dart';

class LiveDataDisplay extends ChangeNotifier{
  void rebuildLiveDataDisplay(){
    notifyListeners();
  }
}


class LiveData{
  static final LiveData _singleton = LiveData._internal();
  static LiveData get shared => _singleton;
  factory LiveData() => _singleton;
  LiveData._internal();

  String? voltage;
  String? current;
  String? power;
  String? energy;
  String? frequency;
  String? powerFactor;
  String? timeStamp;
  LiveDataDisplay? currentLiveDataDisplay;

  void initiateSmartMeter(){
    voltage = null;
    current = null;
    power = null;
    energy = null;
    frequency = null;
    powerFactor = null;
    timeStamp = null;
    currentLiveDataDisplay = LiveDataDisplay();
  }
}