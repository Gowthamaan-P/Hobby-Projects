import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class GraphDataProvider {
  static const url = "https://script.google.com/macros/s/AKfycbwr69GGlI4dhrTm0fqj5-YmdEfNxsPGAx0Jc1Zq3BciK6Fg5yo/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<GraphData>> getGraphData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => GraphData.fromJson(json)).toList();
    });
  }
}


class GraphData {

  String energy;
  String timeStamp;

  GraphData(this.energy, this.timeStamp);

  factory GraphData.fromJson(dynamic json) {
    return GraphData(
        "${json['energy']}",
        "${json['timeStamp']}"
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
    'energy': energy,
    'timeStamp': timeStamp
  };
}

