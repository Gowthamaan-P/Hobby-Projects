import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class LiveDataProvider {
  static const url =
      "https://script.google.com/macros/s/AKfycbwluMCiJoTCZ5M5muaqbXE7HYt7JvcvkLBLQotKDhEkvMeLewQ/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<LiveMeterData>> getLiveMeterData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => LiveMeterData.fromJson(json)).toList();
    });
  }
}


class LiveMeterData {
  String voltage;
  String current;
  String power;
  String energy;
  String frequency;
  String powerFactor;
  String timeStamp;

  LiveMeterData(this.voltage, this.current, this.power, this.energy, this.frequency, this.powerFactor, this.timeStamp);

  factory LiveMeterData.fromJson(dynamic json) {
    return LiveMeterData(
      "${json['voltage']}",
      "${json['current']}",
      "${json['power']}",
      "${json['energy']}",
      "${json['frequency']}",
      "${json['powerFactor']}",
      "${json['timeStamp']}"
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
    'voltage': voltage,
    'current': current,
    'power': power,
    'energy': energy,
    'frequency': frequency,
    'powerFactor': powerFactor,
    'timeStamp': timeStamp
  };
}

