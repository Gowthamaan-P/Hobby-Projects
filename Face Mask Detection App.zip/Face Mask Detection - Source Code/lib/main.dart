//https://www.kaggle.com/andrewmvd/face-mask-detection/tasks

import 'dart:io';
import 'package:flutter/material.dart';
import 'detect_mask.dart';
import 'face_detection_camera.dart';
import 'package:tflite/tflite.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_share/flutter_share.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mask detector',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool _loading;
  List _outputs;
  File _image;
  final picker = ImagePicker();
  int count = 0;
  void initState() {
    super.initState();
    _loading = true;
    loadModel().then((value) {
      setState(() {
        _loading = false;
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> share() async {
    await FlutterShare.share(
        title: 'Hey,I found out a great app!',
        text:
            'Use this app to detect mask in photos/selfies. This app is really awesome.',
        linkUrl: '',
        chooserTitle: 'Hey,I found out a great app!');
  }

  loadModel() async {
    await Tflite.loadModel(
      model: "assets/model.tflite",
      labels: "assets/labels.txt",
    );
  }

  pickImage() async {
    count++;
    print(count);
    var image = await picker.getImage(source: ImageSource.gallery);
    if (image == null) return null;
    setState(() {
      _loading = true;
      //Declare File _image in the class which is used to display the image on the screen.
      _image = File(image.path);
    });
    classifyImage(_image);
  }

  classifyImage(File image) async {
    var output = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 1,
      threshold: 0.5,
      imageMean: 127.5,
      imageStd: 127.5,
    );
    setState(() {
      _loading = false;
      _outputs = output;

      if (count.isOdd) {
        print('hey');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async=>false,
      child: Scaffold(
          backgroundColor: Colors.grey[900],
          appBar: AppBar(
            automaticallyImplyLeading: false,
            title: Text("Mask detector"),
            centerTitle: true,
            backgroundColor: Colors.blue.shade900,
          ),
          floatingActionButton: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              FloatingActionButton(
                heroTag: null,
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return Home();
                      }));
                },
                child: Icon(Icons.image),
              ),
              SizedBox(width: 10),
              FloatingActionButton(
                heroTag: null,
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                    return FaceDetectionFromLiveCamera();
                  }));
                },
                child: Icon(Icons.camera),
              ),
            ],
          ),
          body: _loading
              ? Container(
                  alignment: Alignment.center,
                  child: CircularProgressIndicator(),
                )
              : Container(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _image == null
                          ? Container()
                          : Image.file(_image,
                              fit: BoxFit.contain,
                              height: MediaQuery.of(context).size.height * 0.6),
                      SizedBox(
                        height: 10,
                      ),
                      _outputs != null
                          ? Column(
                              children: <Widget>[
                                Text(
                                  _outputs[0]["label"] == '0 with_mask'
                                      ? "Mask detected"
                                      : "Mask not detected",
                                  style: TextStyle(
                                    color: _outputs[0]["label"] == '0 with_mask'
                                        ? Colors.green
                                        : Colors.red,
                                    fontSize: 25.0,
                                  ),
                                ),
                                Text(
                                  "${(_outputs[0]["confidence"] * 100).toStringAsFixed(0)}%",
                                  style: TextStyle(
                                      color: Colors.purpleAccent, fontSize: 20),
                                )
                              ],
                            )
                          : Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Text(
                                      "Choose a photo from gallery or use the live camera feed to detect face mask",
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                  Container(
                                      child: Image(
                                    image: AssetImage("assets/mask.jpg"),
                                    semanticLabel: 'Mask',
                                    width: MediaQuery.of(context).size.width,
                                    height:
                                        MediaQuery.of(context).size.height * 0.4,
                                  )),
                                  SizedBox(height: 20),
                                  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Text(
                                      "Note: The input photo must have a CLOSE and CLEAR face.",
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 20),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              ),
                            )
                    ],
                  ),
                )),
    );
  }
}
