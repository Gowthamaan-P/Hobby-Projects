package com.example.mask_detector_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
