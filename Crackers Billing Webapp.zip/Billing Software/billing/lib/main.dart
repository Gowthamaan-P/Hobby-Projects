import 'package:billing/application/homepage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'core/common/utils.dart';

void main() {
  runApp(BillingApp());
}

class BillingApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Billing Software',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Varela'
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final username = TextEditingController();
  final password = TextEditingController();

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(10.0)),
          height: height / 2.5,
          width: width / 2.5,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Expanded(
                child: TextFormField(
                  controller: username,
                  validator: (value) {
                    if (value != null) if (value.isEmpty)
                      return "Enter a valid username";
                  },
                  style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500),
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(16),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.grey.shade500,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),
                    hintText: "Username",
                    hintStyle: TextStyle(
                        color: Colors.grey.shade500,
                        fontWeight: FontWeight.w500),
                    prefixIcon: Icon(Icons.account_circle),
                  ),
                  obscureText: false,
                  onSaved: (t) {},
                  onChanged: (text) {},
                ),
              ),
              Expanded(
                child: TextFormField(
                  controller: password,
                  validator: (value){
                    if(value!=null)
                      if(value.isEmpty)
                        return "Enter a valid password";
                  },
                  style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500),
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(16),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.grey.shade500,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),
                    hintText: "Password",
                    hintStyle: TextStyle(
                        color: Colors.grey.shade500,
                        fontWeight: FontWeight.w500),
                    prefixIcon: Icon(Icons.account_circle),
                  ),
                  obscureText: true,
                  onSaved: (t) {},
                  onChanged: (text) {},
                ),
              ),
              MaterialButton(
                onPressed: () => handleLogin(),
                color: Colors.blue.shade900,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                textColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
                child: Text(
                  "LOGIN",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void handleLogin() async{
    if (username.text == 'admin' && password.text == 'admin') {
      final snackBar = SnackBar(
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        content: Text(
          "Login Successful",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold
          ),
        ),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      await Future.delayed(Duration(seconds: 3),(){
        Navigator.of(context).pushReplacement(new MaterialPageRoute(builder: (context) => HomePage()));
      });
    }

    else{
      username.clear();
      password.clear();
      final snackBar = SnackBar(
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        content: Text(
          "Login Error",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold
          ),
        ),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }
}
