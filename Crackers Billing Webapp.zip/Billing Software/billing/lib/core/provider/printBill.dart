import 'dart:convert' as convert;

import 'package:http/http.dart' as http;

class PrintBillProvider {
  // Google App Script Web URL.
  static const String URL =
      "https://script.google.com/macros/s/AKfycbzUP7aTHb8CDeXom2dnPbLuJgN2hd5QYKGWR_gr/exec";

  // Success Status Message
  static const STATUS_SUCCESS = "SUCCESS";

  void addItem(BillingItems item, void Function(String, String) callback) async {
    try {
      await http
          .post(Uri.parse(URL), body: item.toJson())
          .then((response) async {
        print("${response.body}");
        if (response.statusCode == 302) {
          String url = response.headers['location'] ?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status'], convert.jsonDecode(response.body)['status']);
          });
        } else {
          callback(convert.jsonDecode(response.body)['status'], convert.jsonDecode(response.body)['url']);
        }
      });
    } catch (e) {
      print("Error $e");
    }
  }

  void getPdfBill(void Function(String, String) callback) async {
    await http.get(Uri.parse(URL)).then((response) {
      print("${response.body}");
      callback(convert.jsonDecode(response.body)['status'], convert.jsonDecode(response.body)['url']);
    });
  }
}

class BillingItems {
  String itemNames;
  String itemQuantity;
  String itemPrices;
  String itemAmounts;
  String numberOfItems;
  String totalAmount;
  String discount;
  String discountAmount;
  String billAmount;

  BillingItems(
      this.itemNames,
      this.itemQuantity,
      this.itemPrices,
      this.itemAmounts,
      this.numberOfItems,
      this.totalAmount,
      this.discount,
      this.discountAmount,
      this.billAmount);

  factory BillingItems.fromJson(dynamic json) {
    return BillingItems(
        "${json['itemNames']}",
        "${json['itemQuantity']}",
        "${json['itemPrices']}",
        "${json['itemAmounts']}",
        "${json['numberOfItems']}",
        "${json['totalAmount']}",
        "${json['discount']}",
        "${json['discountAmount']}",
        "${json['billAmount']}"
    );
  }

  Map toJson() =>
      {
        'itemNames': itemNames,
        'itemQuantity': itemQuantity,
        'itemPrices': itemPrices,
        'itemAmounts': itemAmounts,
        'numberOfItems': numberOfItems,
        'totalAmount': totalAmount,
        'discount': discount,
        'discountAmount': discountAmount,
        'billAmount': billAmount
      };
}
