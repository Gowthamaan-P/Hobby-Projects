import 'dart:convert' as convert;

import 'package:http/http.dart' as http;


class ItemDataProvider {

  // Google App Script Web URL.
  static const String URL =
      "https://script.google.com/macros/s/AKfycbxMPl8UQ-0drqpOXxtqdWyd6Rl01FZZcI5gcTEEMMgAQz9kH3E/exec";

  // Success Status Message
  static const STATUS_SUCCESS = "SUCCESS";

  void addItem(
      ItemDetails item, void Function(String) callback) async {
    try {
      await http.post(Uri.parse(URL), body: item.toJson()).then((response) async {
        if (response.statusCode == 302) {
          String url = response.headers['location']?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status']);
          });
        } else {
          callback(convert.jsonDecode(response.body)['status']);
        }
      });
    } catch (e) {
      print("Error $e");
    }
  }

  Future<List<ItemDetails>> getItemList() async {
    return await http.get(Uri.parse(URL)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => ItemDetails.fromJson(json)).toList();
    });
  }
}


class ItemDetails {
  String sno;
  String particulars;
  String price;

  ItemDetails(this.sno, this.particulars, this.price);

  factory ItemDetails.fromJson(dynamic json) {
    return ItemDetails(
      "${json['sno']}",
      "${json['particulars']}",
      "${json['price']}"
    );
  }

  Map toJson() => {
    'sno': sno,
    'particulars': particulars,
    'price': price
  };
}
