import 'dart:convert' as convert;

import 'package:http/http.dart' as http;


class SalesHistoryController {

  // Google App Script Web URL.
  static const String URL =
      "https://script.google.com/macros/s/AKfycbxtwa4XrGUIb8YVO4T0VQtQXsq-PvygyjXwoy6hvfIIZUsO2ow/exec";

  // Success Status Message
  static const STATUS_SUCCESS = "SUCCESS";

  void addItem(
      SalesHistory item, void Function(String) callback) async {
    try {
      await http.post(Uri.parse(URL), body: item.toJson()).then((response) async {
        if (response.statusCode == 302) {
          String url = response.headers['location']?? " ";
          await http.get(Uri.parse(url)).then((response) {
            callback(convert.jsonDecode(response.body)['status']);
          });
        } else {
          callback(convert.jsonDecode(response.body)['status']);
        }
      });
    } catch (e) {
      print("Error $e");
    }
  }

  Future<List<SalesHistory>> getItemList() async {
    return await http.get(Uri.parse(URL)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => SalesHistory.fromJson(json)).toList();
    });
  }
}


class SalesHistory {

  String salesId;
  String date;
  String numberOfItems;
  String total;
  String discount;
  String url;

  SalesHistory(this.salesId ,this.date, this.numberOfItems, this.total, this.discount, this.url);

  factory SalesHistory.fromJson(dynamic json) {
    return SalesHistory(
        "${json['salesId']}",
        "${json['date']}",
        "${json['numberOfItems']}",
        "${json['price']}",
        "${json['discount']}",
        "${json['url']}"
    );
  }

  Map toJson() => {
    'salesId': salesId,
    'date': date,
    'numberOfItems': numberOfItems,
    'price': total,
    'discount': discount,
    'url': url
  };
}
