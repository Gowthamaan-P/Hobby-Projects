class BillItem{
  String itemName;
  String itemPrice;
  String itemQuantity;
  String quantityPrice;

  BillItem(this.itemName, this.itemPrice, this.itemQuantity, this.quantityPrice);

  factory BillItem.fromJson(dynamic json) {
    return BillItem(
        "${json['itemName']}",
        "${json['itemPrice']}",
        "${json['itemQuantity']}",
        "${json['quantityPrice']}"
    );
  }

  Map toJson() => {
    'itemName': itemName,
    'itemPrice': itemPrice,
    'itemQuantity': itemQuantity,
    'quantityPrice': quantityPrice
  };
}