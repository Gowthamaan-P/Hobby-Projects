import 'package:billing/core/provider/billingItemprovider.dart';
import 'package:billing/core/provider/database_provider.dart';
import 'package:flutter/material.dart';


void getData()async{
  crackerDetails = await ItemDataProvider().getItemList();
  crackerDetails.reversed.forEach((element) {
    crackerNames.add(element.particulars);
    crackerPrice.add(double.tryParse(element.price)??0.0);
  });
}

List<ItemDetails> crackerDetails = [];
List<String> crackerNames = [];
List<double> crackerPrice = [];
List<BillItem> billItems = [];


class LoadingDialog extends StatelessWidget {
  static void show(BuildContext context, {Key? key}) => showDialog<void>(
    context: context,
    useRootNavigator: false,
    barrierDismissible: false,
    builder: (_) => LoadingDialog(key: key),
  ).then((_) => FocusScope.of(context).requestFocus(FocusNode()));

  static void hide(BuildContext context) => Navigator.pop(context);

  LoadingDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Center(
        child: Container(
          width: 80,
          height: 80,
          padding: EdgeInsets.all(12.0),
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }
}