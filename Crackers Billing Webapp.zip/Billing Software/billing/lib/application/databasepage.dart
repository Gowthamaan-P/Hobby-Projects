import 'package:billing/core/provider/database_provider.dart';
import 'package:billing/core/widgets/datatable_header.dart';
import 'package:billing/core/widgets/responsive_table.dart';
import 'package:flutter/material.dart';


class DatabasePage extends StatefulWidget {
  const DatabasePage({Key? key}) : super(key: key);

  @override
  _DatabasePageState createState() => _DatabasePageState();
}

class _DatabasePageState extends State<DatabasePage> {
  List<ItemDetails> salesList = [];
  late bool isReady;
  List<DatatableHeader> _headers = [
    DatatableHeader(
        text: "S.No",
        value: "id",
        show: true,
        sortable: true,
        textAlign: TextAlign.center),
    DatatableHeader(
        text: "Item",
        value: "item",
        show: true,
        flex: 2,
        sortable: false,
        editable: false,
        textAlign: TextAlign.left),
    DatatableHeader(
        text: "Price",
        value: "price",
        show: true,
        sortable: false,
        textAlign: TextAlign.center),
  ];

  List<int>? _perPages = [10, 20, 50, 100];
  int _total = 100;
  int _currentPerPage = 20;
  List<bool> _expanded = [];
  String _searchKey = "item";

  Widget _dropContainer(data) {
    return Container();
  }

  int _currentPage = 1;
  bool _isSearch = false;
  List<Map<String, dynamic>> _sourceOriginal = [];
  List<Map<String, dynamic>> _sourceFiltered = [];
  List<Map<String, dynamic>> _source = [];
  List<Map<String, dynamic>> _selected = [];

  String? _sortColumn;
  bool _sortAscending = true;
  bool _isLoading = true;
  bool _showSelect = true;

  @override
  void initState() {
    isReady = false;
    _mockPullData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: _title(context),
        ),
        Container(
          child: SingleChildScrollView(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      margin: EdgeInsets.all(10),
                      padding: EdgeInsets.all(0),
                      constraints: BoxConstraints(
                        maxHeight: 650,
                      ),
                      child: Card(
                        elevation: 1,
                        shadowColor: Colors.black,
                        clipBehavior: Clip.none,
                        child: ResponsiveDatatable(
                          title: null,
                          actions: [
                            if (_isSearch)
                              Expanded(
                                  child: TextField(
                                    decoration: InputDecoration(
                                        hintText: 'Enter search term based on ' +
                                            _searchKey
                                                .replaceAll(new RegExp('[\\W_]+'), ' ')
                                                .toUpperCase(),
                                        prefixIcon: IconButton(
                                            icon: Icon(Icons.cancel),
                                            onPressed: () {
                                              setState(() {
                                                _mockPullData();
                                                _isSearch = false;
                                              });
                                            }),
                                        suffixIcon: IconButton(
                                            icon: Icon(Icons.search), onPressed: () {})),
                                    onSubmitted: (value) {
                                      _filterData(value);
                                    },
                                  )),
                            if (!_isSearch)
                              IconButton(
                                  icon: Icon(Icons.search),
                                  onPressed: () {
                                    setState(() {
                                      _isSearch = true;
                                    });
                                  })
                          ],
                          headers: _headers,
                          source: _source,
                          selected: _selected,
                          showSelect: _showSelect,
                          autoHeight: false,
                          dropContainer: _dropContainer,
                          onTabRow: (data) { },
                          onSort: (value) {
                            setState(() => _isLoading = true);

                            setState(() {
                              _sortColumn = value;
                              _sortAscending = !_sortAscending;
                              if (_sortAscending) {
                                _sourceFiltered.sort((a, b) =>
                                    b["$_sortColumn"].compareTo(a["$_sortColumn"]));
                              } else {
                                _sourceFiltered.sort((a, b) =>
                                    a["$_sortColumn"].compareTo(b["$_sortColumn"]));
                              }
                              var _rangeTop = _currentPerPage<_sourceFiltered.length?_currentPerPage:_sourceFiltered.length;
                              _source =
                                  _sourceFiltered.getRange(0, _rangeTop).toList();
                              _searchKey = value;

                              _isLoading = false;
                            });
                          },
                          expanded: _expanded,
                          sortAscending: _sortAscending,
                          sortColumn: _sortColumn,
                          isLoading: _isLoading,
                          onSelect: (value, item) {
                            print("$value  $item ");
                            if (value) {
                              setState(() => _selected.add(item));
                            } else {
                              setState(
                                      () => _selected.removeAt(_selected.indexOf(item)));
                            }
                          },
                          onSelectAll: (value) {
                            if (value) {
                              setState(() => _selected =
                                  _source.map((entry) => entry).toList().cast());
                            } else {
                              setState(() => _selected.clear());
                            }
                          },
                          footers: [
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child: Text("Rows per page:"),
                            ),
                            if (_perPages != null)
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 15),
                                child: DropdownButton(
                                    value: _currentPerPage,
                                    items: _perPages!
                                        .map((e) => DropdownMenuItem(
                                      child: Text("$e"),
                                      value: e,
                                    ))
                                        .toList(),
                                    onChanged: (int? value) {
                                      setState(() {
                                        _currentPerPage = value!;
                                        _currentPage = 1;
                                        _resetData();
                                      });
                                    }),
                              ),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child:
                              Text("$_currentPage - $_currentPerPage of $_total"),
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.arrow_back_ios,
                                size: 16,
                              ),
                              onPressed: _currentPage == 1
                                  ? null
                                  : () {
                                var _nextSet = _currentPage - _currentPerPage;
                                setState(() {
                                  _currentPage = _nextSet > 1 ? _nextSet : 1;
                                  _resetData(start: _currentPage - 1);
                                });
                              },
                              padding: EdgeInsets.symmetric(horizontal: 15),
                            ),
                            IconButton(
                              icon: Icon(Icons.arrow_forward_ios, size: 16),
                              onPressed: _currentPage + _currentPerPage - 1 > _total
                                  ? null
                                  : () {
                                var _nextSet = _currentPage + _currentPerPage;

                                setState(() {
                                  _currentPage = _nextSet < _total
                                      ? _nextSet
                                      : _total - _currentPerPage;
                                  _resetData(start: _nextSet - 1);
                                });
                              },
                              padding: EdgeInsets.symmetric(horizontal: 15),
                            )
                          ],
                        ),
                      ),
                    ),
                  ])),
        ),
      ],
    );
  }

  Widget _title(BuildContext context) {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        text: 'Item Catalog',
        style: TextStyle(
          fontSize: 25,
          fontWeight: FontWeight.w700,
          color: Colors.cyan,
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> getProductList() async {
    salesList = (await ItemDataProvider().getItemList());
    List<Map<String, dynamic>> temps = [];
    salesList.reversed.forEach((element) {
      temps.add({
        'id': element.sno,
        'item': element.particulars,
        'price': element.price
      });
    });
    return temps;
  }

  _mockPullData() async {
    print("Mock Pull Data");
    _expanded = List.generate(_currentPerPage, (index) => false);
    if(mounted){
      setState(() => _isLoading = true);
    }
    Future.delayed(Duration(seconds: 3)).then((value) async {
      _sourceOriginal.clear();
      _sourceOriginal.addAll(await getProductList());
      _sourceFiltered = _sourceOriginal;
      _total = _sourceFiltered.length;
      _source =  _sourceFiltered.getRange(0, (_sourceFiltered.length>_currentPerPage)?_currentPerPage:_sourceFiltered.length).toList();
      if(mounted){
        setState(() => _isLoading = false);
      }
    });
  }

  _resetData({start: 0}) async {
    if(mounted){
      setState(() => _isLoading = true);
    }
    var _expandedLen =
    _total - start < _currentPerPage ? _total - start : _currentPerPage;
    Future.delayed(Duration(seconds: 0)).then((value) {
      _expanded = List.generate(_expandedLen.toInt(), (index) => false);
      _source.clear();
      _source = _sourceFiltered.getRange(start, start + _expandedLen).toList();
      if(mounted){
        setState(() => _isLoading = false);
      }
    });
  }

  _filterData(value) {
    if(mounted){
      setState(() => _isLoading = true);
    }
    try {
      if (value == "" || value == null) {
        _sourceFiltered = _sourceOriginal;
      } else {
        _sourceFiltered = _sourceOriginal
            .where((data) => data[_searchKey]
            .toString()
            .toLowerCase()
            .contains(value.toString().toLowerCase()))
            .toList();
      }

      _total = _sourceFiltered.length;
      var _rangeTop = _total < _currentPerPage ? _total : _currentPerPage;
      _expanded = List.generate(_rangeTop, (index) => false);
      _source = _sourceFiltered.getRange(0, _rangeTop).toList();
    } catch (e) {
      print(e);
    }
    if(mounted){
      setState(() => _isLoading = false);
    }
  }
}
