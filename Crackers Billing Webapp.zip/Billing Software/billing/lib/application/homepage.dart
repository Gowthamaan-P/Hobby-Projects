import 'package:billing/core/common/utils.dart';
import 'package:billing/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:billing/application/databasepage.dart';
import 'package:billing/application/salesHistoryPage.dart';
import 'package:billing/core/provider/billingItemprovider.dart';
import 'package:billing/core/provider/printBill.dart';
import 'package:billing/core/provider/saleshistoryprovider.dart';
import 'package:billing/core/widgets/autocompletefield.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:js' as js;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  double displayTotal = 0.0, total = 0.0;
  int discountPercent = 0;

  final itemName = TextEditingController();
  final quantity = TextEditingController();
  final id = TextEditingController();
  final discountText = TextEditingController();
  final listQuantity = TextEditingController();

  GlobalKey<AutoCompleteTextFieldState<String>>? itemList;
  GlobalKey<AutoCompleteTextFieldState<String>>? itemId;
  GlobalKey<AutoCompleteTextFieldState<String>>? itemQuantity;

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    double heights = MediaQuery.of(context).size.height;
    double height = MediaQuery.of(context).size.height-140;
    double width = MediaQuery.of(context).size.width;

    return WillPopScope(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          toolbarHeight: 70,
          backgroundColor: Colors.blue.shade900,
          actions: [
            PopupMenuButton<String>(
              onSelected: handleClick,
              itemBuilder: (BuildContext context) {
                return {'Settings', 'About','Logout'}.map((String choice) {
                  return PopupMenuItem<String>(
                    value: choice,
                    child: Text(
                      choice,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w400),
                    ),
                  );
                }).toList();
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Container(
            height: heights-90,
            width: width,
            child: Column(
              children: <Widget>[
                Container(
                  width: width,
                  height: height * 0.15,
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Text(
                                "Discount: ",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: ((height * 0.15) - 20) * 0.28,
                                    fontWeight: FontWeight.bold),
                              ),
                              Container(
                                constraints: BoxConstraints(maxWidth: 100),
                                padding: EdgeInsets.all(0),
                                margin: EdgeInsets.all(0),
                                child: TextField(
                                  enabled: true,
                                  decoration: InputDecoration(
                                    contentPadding: EdgeInsets.all(0),
                                    border: InputBorder.none,
                                  ),
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: ((height * 0.15) - 20) * 0.28,
                                      fontWeight: FontWeight.bold),
                                  controller: discountText,
                                  onSubmitted: (newValue){
                                    setState(() {
                                      print("$discountPercent");
                                      discountPercent = newValue.isEmpty? 0:int.parse(newValue);
                                      print("$discountPercent");
                                      displayTotal = total;
                                      if(discountPercent>0){
                                        displayTotal = displayTotal- (discountPercent*displayTotal)/100;
                                      }
                                    });
                                  },
                                  onChanged: (newValue) {},
                                ),
                              ),
                              Text(
                                "%",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: ((height * 0.15) - 20) * 0.28,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Text(
                            "Total",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: ((height * 0.15) - 20) * 0.28,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text(
                        "${displayTotal.toStringAsFixed(2)}",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: (height * 0.15) - 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  width: width,
                  height: (height * 0.85) - 20,
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: (height * 0.15) - 10,
                        width: width,
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: SimpleAutoCompleteTextField(
                                  key: itemId,
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(10.0),
                                    fillColor: Colors.white,
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                      BorderSide(color: Colors.grey.shade500),
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(20.0)),
                                    ),
                                    hintText: "Item Number",
                                    hintStyle: TextStyle(
                                        color: Colors.grey.shade500,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  controller: id,
                                  suggestions: [],
                                  textInputAction: TextInputAction.done,
                                  clearOnSubmit: false,
                                  submitOnSuggestionTap: true,
                                  textChanged: (value) {
                                    setState(() {
                                      itemName.text =
                                      crackerNames[(int.tryParse(value!) ?? 1)-1 ];
                                    });
                                  },
                                  textSubmitted: (value) {
                                    setState(() {
                                      itemName.text =
                                      crackerNames[(int.tryParse(value!) ?? 1)-1];
                                    });
                                  },
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: SimpleAutoCompleteTextField(
                                  key: itemList,
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(10.0),
                                    fillColor: Colors.white,
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                      BorderSide(color: Colors.grey.shade500),
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(20.0)),
                                    ),
                                    hintText: "Item",
                                    hintStyle: TextStyle(
                                        color: Colors.grey.shade500,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  controller: itemName,
                                  suggestions: crackerNames,
                                  suggestionsAmount: 20,
                                  textInputAction: TextInputAction.done,
                                  clearOnSubmit: false,
                                  submitOnSuggestionTap: true,
                                  textChanged: (value) {
                                    setState(() {
                                      id.text = (crackerNames.indexOf(value!)+1).toString();
                                    });
                                  },
                                  textSubmitted: (value) {
                                    setState(() {
                                      id.text = (crackerNames.indexOf(value!)+1).toString();
                                    });
                                  },
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: SimpleAutoCompleteTextField(
                                  key: itemQuantity,
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(10.0),
                                    fillColor: Colors.white,
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                      BorderSide(color: Colors.grey.shade500),
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(20.0)),
                                    ),
                                    hintText: "Quantity",
                                    hintStyle: TextStyle(
                                        color: Colors.grey.shade500,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  controller: quantity,
                                  suggestions: [],
                                  textInputAction: TextInputAction.done,
                                  clearOnSubmit: false,
                                  submitOnSuggestionTap: true,
                                  textChanged: (value) {},
                                  textSubmitted: (value) {},
                                ),
                              ),
                            ),
                            MaterialButton(
                              onPressed: () {
                                print(
                                    "${id.text}   ${itemName.text}    ${quantity.text}");
                                if (id.text.isNotEmpty &&
                                    itemName.text.isNotEmpty &&
                                    quantity.text.isNotEmpty) {
                                  String quantityPrice = ((int.tryParse(quantity.text.trim()) ?? 0) * (crackerPrice[(int.tryParse(id.text) ?? 1) - 1])).toStringAsFixed(2);
                                  billItems.add(BillItem(
                                      itemName.text.trim(),
                                      crackerPrice[(int.tryParse(id.text) ?? 1) - 1]
                                          .toStringAsFixed(2),
                                      quantity.text.trim(),
                                      quantityPrice));
                                  total = total + (double.tryParse(quantityPrice)??0.0);
                                  displayTotal = total;
                                  if(discountPercent>0){
                                    displayTotal = (discountPercent*displayTotal)/100;
                                  }
                                  setState(() {
                                    id.clear();
                                    itemName.clear();
                                    quantity.clear();
                                  });
                                }
                              },
                              color: Colors.blue.shade900,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0)),
                              textColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 30, vertical: 20),
                              child: Text(
                                "Add Item",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: (height * 0.7) - 30,
                        width: width,
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Column(
                          children: <Widget>[
                            ListTile(
                              leading: Text("X",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: <Widget>[
                                  Text("S.No",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold)),
                                  Text("Item",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold)),
                                  Text("Quantity",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold)),
                                  Text("Unit Price",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold)),
                                ],
                              ),
                              trailing: Text("Amount",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ),
                            SizedBox(
                              height: (height * 0.65) - 50,
                              child: ListView.builder(
                                  itemCount: billItems.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return ListTile(
                                      leading: IconButton(
                                          onPressed: () {
                                            billItems.removeAt(index);
                                            total = 0;
                                            billItems.forEach((element) {
                                              double temp = double.tryParse(element.quantityPrice) ?? 0.0;
                                              total = total + temp;
                                            });
                                            displayTotal = total;
                                            if(discountPercent>0){
                                              displayTotal = total - (discountPercent*displayTotal)/100;
                                            }
                                            setState(() {});
                                          },
                                          icon: Icon(
                                            Icons.cancel,
                                            color: Colors.red,
                                          )),
                                      title: Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: <Widget>[
                                          Text("${index + 1}",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.black)),
                                          Text("${billItems[index].itemName}",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.black)),
                                          Container(
                                            constraints: BoxConstraints(maxWidth: 150),
                                            padding: EdgeInsets.all(0),
                                            margin: EdgeInsets.all(0),
                                            child: TextField(
                                              enabled: true,
                                              decoration: InputDecoration(
                                                contentPadding: EdgeInsets.all(0),
                                                border: InputBorder.none,
                                              ),
                                              textAlign: TextAlign.center,
                                              controller: TextEditingController.fromValue(TextEditingValue(
                                                  text: "${billItems[index].itemQuantity}"),
                                              ),
                                              onChanged: (newValue) {
                                                billItems[index].itemQuantity =
                                                    newValue;
                                                String quantityPrice =
                                                ((int.tryParse(newValue) ?? 0) *
                                                    (double.parse(
                                                        billItems[index]
                                                            .itemPrice)))
                                                    .toStringAsFixed(2);
                                                billItems[index].quantityPrice =
                                                    quantityPrice;
                                                total = 0;
                                                billItems.forEach((element) {
                                                  double temp = double.tryParse(element.quantityPrice) ?? 0.0;
                                                  total = total + temp;
                                                });
                                                displayTotal = total;
                                                if(discountPercent>0){
                                                  displayTotal = total - (discountPercent*displayTotal)/100;
                                                }
                                                setState(() {});
                                              },
                                            ),
                                          ),
                                          Text("${billItems[index].itemPrice}",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.black)),
                                        ],
                                      ),
                                      trailing: Text(
                                          "${billItems[index].quantityPrice}",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold)),
                                    );
                                  }),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 50,
                  width: width,
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          // MaterialButton(
                          //   child: Text(
                          //     "Sales History",
                          //     textAlign: TextAlign.center,
                          //     style: TextStyle(
                          //         color: Colors.black,
                          //         fontSize: 20,
                          //         fontWeight: FontWeight.w400
                          //     ),
                          //   ),
                          //   onPressed:  (){
                          //     Navigator.of(context).push(new MaterialPageRoute(builder: (context) => SalesHistoryPage()));
                          //   },
                          // ),
                          MaterialButton(
                            child: Text(
                              "Item Catalog",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w400
                              ),
                            ),
                            onPressed:  (){
                              Navigator.of(context).push(new MaterialPageRoute(builder: (context) => DatabasePage()));
                            },
                          ),
                          MaterialButton(
                            child: Text(
                              "Help",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w400
                              ),
                            ),
                            onPressed:  (){ },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          MaterialButton(
                            onPressed: () {
                              setState(() {
                                clearBill();
                              });
                            },
                            color: Colors.red,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            textColor: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
                              child: Text(
                                "Cancel Bill",
                                textAlign: TextAlign.center,
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                              ),
                            ),
                          ),
                          SizedBox(width: 10,),
                          MaterialButton(
                            onPressed: () {
                              LoadingDialog.show(context);
                              printBill();
                            },
                            color: Colors.blue.shade900,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            textColor: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
                              child: Text(
                                "Print",
                                textAlign: TextAlign.center,
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
      onWillPop: () async => false,
    );
  }

  void handleClick(String value)async{
    switch (value) {
      case 'Logout':
        bool isLoggedOut = (await showDialog(
          context: context,
          builder: (context) => new AlertDialog(
            title: Text(
              "Confirm Logout",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold
              ),
            ),
            content: Text(
              "Would you like to logout of the Billing Panel?",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w400,
              ),
            ),
            actions: [
              MaterialButton(
                child: Text(
                  "Cancel",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.green.shade900,
                      fontWeight: FontWeight.w400
                  ),
                ),
                onPressed: ()=> Navigator.of(context).pop(false),
              ),
              MaterialButton(
                child: Text(
                  "Logout",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.redAccent.shade700,
                      fontWeight: FontWeight.w400
                  ),
                ),
                onPressed:  (){
                  Navigator.of(context).pop(true);
                },
              ),
            ],
          ),
        )) ?? false;
        if(isLoggedOut){
          Navigator.of(context).pushReplacement(new MaterialPageRoute(builder: (context) => LoginPage()));
        }
        break;
      case 'Settings':
        break;
      case 'About':
        break;
    }
  }

  void printBill() {
    String itemNames = '';
    String itemQuantity = '';
    String itemPrices = '';
    String itemAmounts = '';
    String numberOfItems = billItems.length.toString();
    double totalAmount = 0.0;
    int discount = 0;
    double discountAmount;
    double billAmount;

    billItems.forEach((element) {
      itemNames = itemNames + element.itemName + "|";
      itemQuantity = itemQuantity + element.itemQuantity + "|";
      itemPrices = itemPrices + element.itemPrice + "|";
      itemAmounts = itemAmounts + element.quantityPrice + "|";
      double temp = double.tryParse(element.quantityPrice) ?? 0.0;
      totalAmount = totalAmount + temp;
    });
    discount = discountPercent;
    discountAmount = (discountPercent * totalAmount) / 100;
    billAmount = totalAmount - discountAmount;
    print("$itemNames \n $itemQuantity \n$itemAmounts \n$itemPrices  \n$discount  \n$discountAmount \n$billAmount  \n$totalAmount");
    BillingItems currentBill = BillingItems(
        itemNames,
        itemQuantity,
        itemPrices,
        itemAmounts,
        numberOfItems,
        totalAmount.toStringAsFixed(2),
        discount.toString(),
        discountAmount.toStringAsFixed(2),
        billAmount.toStringAsFixed(2));

    PrintBillProvider billPrinter = PrintBillProvider();
    SalesHistoryController salesReport = SalesHistoryController();

    billPrinter.addItem(currentBill, (String response, String url) {
      print("Response: $response");
      print("Url: $url");

      billPrinter.getPdfBill((String response, String url)async{
        print("PDF Response: $response");
        print("Url: $url");
        js.context.callMethod('open', [url]);
        List<SalesHistory> len = await salesReport.getItemList();
        SalesHistory sale = SalesHistory(len.length.toString() ,
            DateTime.now().toIso8601String(), currentBill.numberOfItems,
            billAmount.toStringAsFixed(2), currentBill.discount, url);
        salesReport.addItem(sale, (String status) {
          print("$status");
        });
        LoadingDialog.hide(context);
        clearBill();
      });
    });
  }

  void clearBill() {
    itemName.clear();
    quantity.clear();
    id.clear();
    discountPercent = 0;
    displayTotal = 0.0;
    billItems.clear();
    total = 0;
    setState(() { });
  }
}
