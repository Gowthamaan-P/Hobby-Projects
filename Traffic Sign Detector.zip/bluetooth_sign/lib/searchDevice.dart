import 'dart:async';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:bluetooth_sign/animation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue/flutter_blue.dart';

class SearchDevices extends StatefulWidget {
  const SearchDevices({Key key}) : super(key: key);
  @override
  _SearchDevicesState createState() => _SearchDevicesState();
}

class _SearchDevicesState extends State<SearchDevices> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]);

    return WillPopScope(
      child: StreamBuilder<BluetoothState>(
          stream: FlutterBlue.instance.state,
          initialData: BluetoothState.unknown,
          builder: (c, snapshot) {
            final state = snapshot.data;
            if (state == BluetoothState.on) {
              return FindDevicesScreen();
            }
            return BluetoothOffScreen(state: state);
          }),
      onWillPop: () async => false,
    );
  }
}

///Bluetooth Off Screen
class BluetoothOffScreen extends StatelessWidget {
  const BluetoothOffScreen({Key key, this.state}) : super(key: key);

  ///Bluetooth state [ON] or [OFF]
  final BluetoothState state;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    width = width >= 1280 ? 1280 : width;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          height: height,
          width: width,
          color: Colors.blue.shade900,
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(
                  Icons.bluetooth_disabled,
                  size: 200.0,
                  color: Colors.white54,
                ),
                Text(
                  'Bluetooth Adapter is ${state != null ? state.toString().substring(15) : 'not available'}.',
                  style: TextStyle(color: Colors.white),
                ),
                Text(
                  'Turn on Bluetooth to connect to Jeevan Lite or use USB connection',
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

///FindDevices Screen
class FindDevicesScreen extends StatefulWidget {
  const FindDevicesScreen({Key key}) : super(key: key);
  @override
  _FindDevicesScreenState createState() => _FindDevicesScreenState();
}

class _FindDevicesScreenState extends State<FindDevicesScreen> {
  bool isSignFound;
  AudioCache _audioCache = AudioCache();

  int signalStrength = 0;
  double deviceDistance = 0.0;

  @override
  void initState() {
    super.initState();
    isSignFound = false;
    periodicScanTimer();
    _audioCache = AudioCache(prefix: "assets/images/", fixedPlayer: AudioPlayer()..setReleaseMode(ReleaseMode.STOP));
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    print("Rebuilt: $isSignFound");

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SizedBox(
          width: width,
          child: Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              title: Text(
                'Traffic Sign Identifier',
                style: TextStyle(fontSize: 25.0),
              ),
              automaticallyImplyLeading: false,
              centerTitle: true,
              backgroundColor: Colors.black,
              toolbarHeight: 60.0,
            ),
            body: isSignFound
                ? Center(
              child: Container(
                width: width * 0.5,
                height: height * 0.7,
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      width: width * 0.45,
                      height: height * 0.45,
                      child: Image.asset(
                          "assets/images/speed_limit.jpg"),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Text(
                      'Speed Limit 40 Km/Hr',
                      style: TextStyle(
                          fontSize: 35.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            )
                : Container(
              width: width,
              height: height,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/images/road.jpg"),
                      fit: BoxFit.fill)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      '  $signalStrength dB, $deviceDistance m',
                      style: TextStyle(
                          fontSize: 15.0, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Text(
                    'Ride Safe',
                    style: TextStyle(
                        fontSize: 35.0, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Looking for road signs...',
                    style: TextStyle(
                        fontSize: 35.0, fontWeight: FontWeight.bold),
                  ),
                  LoaderWidget(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  double distance(int rssi) {
    return pow(10, ((-83.0 - (rssi)) / (10.0 * 2.5)));
  }

  ///Detect Devices
  void detectDevices(List<ScanResult> devices) async{
    debugPrint("Signal detector Started");
    for(int i=0;i<devices.length;i++){
      print(devices[i].device.name);
      /*if(devices[i].device.name.contains("school zone limit 40")){
        signalStrength = devices[i].rssi;
        deviceDistance = distance(devices[i].rssi);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          setState(() {
            isSignFound = false;
          });
        });
      }*/

     if (devices[i].device.name.contains("school zone limit 40") && distance(devices[i].rssi) <= 8) {
        print("Sign Found: ${devices[i].device.name}");
        WidgetsBinding.instance.addPostFrameCallback((_) {
          setState(() {
            isSignFound = true;
          });
        });
        _audioCache.play('Speed_limit.mp3').whenComplete((){
          _audioCache.play('Speed_limit.mp3').whenComplete((){
            _audioCache.play('Speed_limit.mp3');
          });
        });
        break;
      }
    }
    debugPrint("Signal detector Terminated");
    await Future.delayed(Duration(seconds: 3),(){});
    setState(() {
      isSignFound = false;
    });
    await Future.delayed(Duration(seconds: 2),(){});
    debugPrint("Signal Scanner Called");
    periodicScanTimer();
  }

  ///Bluetooth Scanner
  void periodicScanTimer(){
    FlutterBlue.instance.startScan(timeout: Duration(seconds: 1), allowDuplicates: false, scanMode: ScanMode.balanced).whenComplete(()async{
      debugPrint("Scan Completed");
      List<ScanResult> devices = await FlutterBlue.instance.scanResults.first;
      debugPrint("${devices.length}");
      debugPrint("Signal detector Initiated");
      detectDevices(devices);
    });
  }
}
