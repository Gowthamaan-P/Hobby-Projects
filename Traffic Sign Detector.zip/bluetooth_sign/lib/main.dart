import 'package:bluetooth_sign/searchDevice.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(BluetoothSign());
}

class BluetoothSign extends StatelessWidget {
  const BluetoothSign({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
        primarySwatch: Colors.blue,
      ),
      home: SearchDevices(),
    );
  }
}
