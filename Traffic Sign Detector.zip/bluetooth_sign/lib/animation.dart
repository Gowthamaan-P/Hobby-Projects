import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

class LoaderWidget extends StatelessWidget {
  const LoaderWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return SizedBox(
      height: height/2.1,
      width: width/2.5,
      child: RiveAnimation.asset(
        'assets/images/searching.riv',
        fit: BoxFit.cover,
      ),
    );
  }
}
