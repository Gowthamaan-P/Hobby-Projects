package com.example.bluetooth_sign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
