package com.example.padhu_spo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
