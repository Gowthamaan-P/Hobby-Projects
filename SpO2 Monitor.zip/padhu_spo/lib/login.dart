import 'package:flutter/material.dart';
import 'package:padhu_spo/homeScreen.dart';

import 'widgets/background.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final username = TextEditingController();
  final password = TextEditingController();
  bool showText = true;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.deepPurple.shade900,
      body: Background(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: const Text(
                "Welcome!",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 0.5,
                    fontSize: 36
                ),
                textAlign: TextAlign.left,
              ),
            ),

            SizedBox(height: size.height * 0.08),

            Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: username,
                style: const TextStyle(
                    color: Colors.white,
                    letterSpacing: 0.5,
                    fontSize: 20
                ),
                decoration: const InputDecoration(
                    labelText: "Username",
                  labelStyle: TextStyle(
                      color: Colors.grey,
                      letterSpacing: 0.5,
                      fontSize: 20
                  )
                ),
              ),
            ),

            SizedBox(height: size.height * 0.03),

            Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: password,
                style: const TextStyle(
                    color: Colors.white,
                    letterSpacing: 0.5,
                    fontSize: 20
                ),
                obscureText: showText,
                decoration: InputDecoration(
                  suffixIcon: IconButton(onPressed: (){
                    showText = !showText;
                    setState(() {});
                  }, icon: showText? Icon(Icons.visibility):Icon(Icons.visibility_off)),
                    labelText: "Password",
                    labelStyle: const TextStyle(
                        color: Colors.grey,
                        letterSpacing: 0.5,
                        fontSize: 20
                    )
                ),
              ),
            ),

            SizedBox(height: size.height * 0.05),

            Container(
              alignment: Alignment.centerRight,
              margin: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              child: MaterialButton(
                onPressed: () {
                  if(username.text=='admin' && password.text=='admin'){
                    Navigator.of(context).pushReplacement(new MaterialPageRoute(builder: (context) => HomeScreen()));
                  }else{
                    const snackBar = SnackBar(content: Text('Please verify your login credentials'));
                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                  }
                },
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
                textColor: Colors.white,
                padding: const EdgeInsets.all(0),
                child: Container(
                  alignment: Alignment.center,
                  height: 50.0,
                  width: size.width * 0.5,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(80.0),
                      gradient: const LinearGradient(
                          colors: [
                            Color.fromARGB(255, 255, 136, 34),
                            Color.fromARGB(255, 255, 177, 41)
                          ]
                      )
                  ),
                  padding: const EdgeInsets.all(0),
                  child: const Text(
                    "Login",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                      letterSpacing: 0.6,
                      fontSize: 25
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}