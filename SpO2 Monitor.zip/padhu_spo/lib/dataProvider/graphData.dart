import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class GraphDataProvider {
  static const url = "https://script.google.com/macros/s/AKfycbxw6-6oCizK8ovGcDxukMz7U1DlnfOGrYObUKi5rLLCkMhhZyj8kPfSmcn3-dhq_Th_/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<GraphData>> getGraphHelmetData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => GraphData.fromJson(json)).toList();
    });
  }
}

class GraphData {

  String valueOne;
  String valueTwo;
  String timestamp;

  GraphData({
    required this.valueOne,
    required this.valueTwo,
    required this.timestamp,
  });

  factory GraphData.fromJson(dynamic json) {
    return GraphData(
        valueOne: "${json['valueOne']}",
        valueTwo: "${json['valueTwo']}",
        timestamp: "${json['timestamp']}");
  }

  // Method to make GET parameters.
  Map toJson() => {
    'valueOne': valueOne,
    'valueTwo': valueTwo,
    'timestamp':timestamp
  };
}
