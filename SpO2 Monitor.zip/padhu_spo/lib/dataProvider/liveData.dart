import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class LiveDataProvider {
  static const url = "https://script.google.com/macros/s/AKfycbztnE8g6kPQ3Yad1fX5BKXxUBd1pfjdJpfMxHN4BKaG1eDk4yEd_cGFT2hkmQCXRUuiSQ/exec";

  static const statusSuccess = "SUCCESS";

  Future<List<LiveData>> getLiveMeterData() async {
    return await http.get(Uri.parse(url)).then((response) {
      var jsonFeedback = convert.jsonDecode(response.body) as List;
      return jsonFeedback.map((json) => LiveData.fromJson(json)).toList();
    });
  }
}

class LiveData {

  String? valueOne;
  String? valueTwo;


  LiveData({
    required this.valueOne,
    required this.valueTwo,

  });

  factory LiveData.fromJson(dynamic json) {
    return LiveData(
        valueOne: "${json['valueOne']}",
        valueTwo: "${json['valueTwo']}",
    );
  }

  // Method to make GET parameters.
  Map toJson() => {
    'valueOne': valueOne,
    'valueTwo': valueTwo,
  };
}
