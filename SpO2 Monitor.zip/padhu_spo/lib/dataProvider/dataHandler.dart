import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:padhu_spo/dataProvider/liveData.dart';

class LiveDataDisplay extends ChangeNotifier{
  void rebuildLiveDataDisplay(){
    notifyListeners();
  }
}


class CurrentLiveData{
  static final CurrentLiveData _singleton = CurrentLiveData._internal();
  static CurrentLiveData get shared => _singleton;
  factory CurrentLiveData() => _singleton;
  CurrentLiveData._internal();

  String? valueOne;
  String? valueTwo;
  LiveDataDisplay? currentLiveDataDisplay;


  void initiateSmartMeter(){
    valueOne = null;
    valueTwo = null;
    currentLiveDataDisplay = LiveDataDisplay();
  }
}

class DataHandler {
  static final DataHandler _singleton = DataHandler._internal();
  static DataHandler get shared => _singleton;
  factory DataHandler() => _singleton;
  DataHandler._internal();

  Timer? liveDataTimer;
  String previousValueOneState = '-1', previousValueTwoState = '-1';


  void liveDataProvider() {

    liveDataTimer = Timer.periodic(const Duration(seconds: 3), (timer) async {
      List<LiveData> liveData = await LiveDataProvider().getLiveMeterData();

      if (liveData.isNotEmpty) {
        LiveData meterData = liveData.last;
        CurrentLiveData.shared.valueOne = meterData.valueOne;
        CurrentLiveData.shared.valueTwo = meterData.valueTwo;
        if(previousValueOneState!=CurrentLiveData.shared.valueOne || previousValueTwoState!=CurrentLiveData.shared.valueTwo){
          previousValueOneState =CurrentLiveData.shared.valueOne!;
          previousValueTwoState =CurrentLiveData.shared.valueTwo!;
          CurrentLiveData.shared.currentLiveDataDisplay!.rebuildLiveDataDisplay();
        }
      }
    });
  }


  void dispose() {
    liveDataTimer?.cancel();
  }
}
