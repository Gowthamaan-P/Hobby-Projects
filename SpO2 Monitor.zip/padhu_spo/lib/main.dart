import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:padhu_spo/splashscreen.dart';

void main() {
  runApp(const SpoApp());
}

class SpoApp extends StatelessWidget {
  const SpoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.firaSansCondensedTextTheme(),
        primaryColor: const Color(0xFF2661FA),
        scaffoldBackgroundColor: Colors.white,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SplashScreen(),
    );
  }
}