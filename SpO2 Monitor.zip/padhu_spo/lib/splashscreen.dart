import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:padhu_spo/dataProvider/dataHandler.dart';
import 'package:padhu_spo/login.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {

  startTime() async {
    var duration = const Duration(seconds: 3);
    return Timer(duration, navigationPage);
  }

  void navigationPage() {
    if(mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => const LoginScreen()));
    }
  }

  @override
  void initState() {
    super.initState();
    startTime();
    CurrentLiveData.shared.initiateSmartMeter();
    DataHandler.shared.liveDataProvider();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitDown,
      DeviceOrientation.portraitUp,
    ]);

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky, overlays: []);

    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.deepPurple.shade900,
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: height * 0.24,
              width: (width / 2.25),
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.fill,
                      image: AssetImage(
                        "assets/images/logo.png",
                      ))),
            ),
            const SizedBox(height: 35),
            Text(
              "Medimetria",
              style: TextStyle(
                  fontSize: height * 0.06,
                  color: Colors.white,
                  letterSpacing: 0.6,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}