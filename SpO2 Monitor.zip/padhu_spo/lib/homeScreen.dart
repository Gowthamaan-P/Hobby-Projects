import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:padhu_spo/widgets/background.dart';
import 'package:padhu_spo/dataProvider/dataHandler.dart';
import 'package:padhu_spo/login.dart';
import 'package:padhu_spo/widgets/card_main.dart';
import 'package:padhu_spo/widgets/custom_clipper.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    DataHandler.shared.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Stack(
        children: <Widget>[
          ClipPath(
            clipper: MyCustomClipper(clipType: ClipType.bottom),
            child: Container(
              color: Colors.deepPurple.shade900,
              height: Constants.headerHeight + statusBarHeight,
            ),
          ),
          Positioned(
            right: -45,
            top: -30,
            child: ClipOval(
              child: Container(
                color: Colors.white.withOpacity(0.1),
                height: 220,
                width: 220,
              ),
            ),
          ),
          Positioned(
            right: 10,
            top: 30,
            child: PopupMenuButton<String>(
              icon: Icon(Icons.adaptive.more, color: Colors.white),
              onSelected: (choice) {
                handleMenu(choice);
              },
              itemBuilder: (BuildContext context) {
                return {'Help', 'Logout'}.map((String choice) {
                  return PopupMenuItem<String>(
                    value: choice,
                    child: Text(
                      choice,
                      style: const TextStyle(
                          fontSize: 22, letterSpacing: 1),
                    ),
                  );
                }).toList();
              },
            ),
          ),


          // BODY
          Padding(
            padding: EdgeInsets.all(Constants.paddingSide),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 15),
                Container(
                  height: 100,
                  width: 100,
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage(
                            "assets/images/logo.png",
                          ))),
                ),
                const SizedBox(height: 15),
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Welcome to Medimetria !",
                    style: TextStyle(
                        fontSize: 20,
                        letterSpacing: 1.0,
                        fontWeight: FontWeight.w900,
                        color: Colors.white),
                  ),
                ),
                const Spacer(),
                ChangeNotifierProvider.value(
                    value: CurrentLiveData.shared.currentLiveDataDisplay!,
                    child: Consumer<LiveDataDisplay>(
                        builder: (context, value, child) {
                          return CardIcon(
                            icon: const Icon(
                              Icons.water,
                              size: 20,
                            ),
                            title: "Heartbeat",
                            value: CurrentLiveData.shared.valueOne??'...',
                            unit: "bpm",
                            color: Constants.lightGreen,
                            graphPage: Container(),
                          );
                        })),
                const SizedBox(height: 20),
                ChangeNotifierProvider.value(
                    value: CurrentLiveData.shared.currentLiveDataDisplay!,
                    child: Consumer<LiveDataDisplay>(
                        builder: (context, value, child) {
                          return CardIcon(
                            icon: const Icon(
                              Icons.air,
                              size: 20,
                            ),
                            title: "SpO2",
                            value: CurrentLiveData.shared.valueTwo??'...',
                            unit: "%",
                            color: Constants.lightYellow,
                            graphPage: Container(),
                          );
                        })),
                const SizedBox(height: 70),
              ],
            ),
          )
        ],
      ),
    );
  }

  void handleMenu(String value) {
    switch (value) {
      case 'Logout':
        Navigator.of(context, rootNavigator: true).pushReplacement(
            CupertinoPageRoute(
                builder: (BuildContext context) => const LoginScreen()));
        break;
      case 'Help':
        break;
      default:
        break;
    }
  }
}
