import "package:permission_handler/permission_handler.dart";

class PermissionService {
  ///SingleTon Class Declaration
  static final PermissionService _singleton = PermissionService._internal();
  factory PermissionService() => _singleton;
  PermissionService._internal();
  static PermissionService get shared => _singleton;

  ///Private Function to Request User Permission
  Future<bool> _requestPermissions() async {
    var request = PermissionStatus.denied;
    await Permission.camera.request().then((value)async{
      await Permission.storage.request().then((value)async{
        await Permission.microphone.request().then((value) async{
          request = PermissionStatus.granted;
        });
      });
    } );

    ///If Permissions verification
    if (request==PermissionStatus.granted){
      return true;
    }
    return false;
  }

  ///Request Call Handler
  Future<bool> requestUserPermission({Function? onPermissionDenied}) async {
    var granted = await _requestPermissions();
    if (!granted) {
      onPermissionDenied!();
    }
    return granted;
  }

  ///Verify a particular Permission status
  Future<bool> hasPermission(Permission permission) async {
    var permissionStatus = await permission.status;
    return permissionStatus == PermissionStatus.granted;
  }
}
