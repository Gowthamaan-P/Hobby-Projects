import 'package:flutter/material.dart';

void preCacheImages(BuildContext context){
  final List<String> imagesPath = [
    "assets/images/logo.png"
  ];

  for (var element in imagesPath) {
    precacheImage(AssetImage(element), context);
  }
}