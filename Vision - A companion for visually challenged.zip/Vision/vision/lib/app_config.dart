import 'package:flutter/material.dart';
import 'package:vision/core/services/permissionService.dart';
import 'package:vision/presentation/preCacheImages.dart';
import 'package:vision/views/splashScreen.dart';


///Runtime Broker to manage apps life cycle, foreground service and screen on and off limits.
class RunTimeBroker extends StatefulWidget {
  const RunTimeBroker({Key? key}) : super(key: key);
  @override
  RunTimeBrokerState createState() => RunTimeBrokerState();
}

class RunTimeBrokerState extends State<RunTimeBroker>
    with WidgetsBindingObserver {

  bool isPermissionGranted =  false;

  @override
  void initState() {
    super.initState();
    ///Initiate Application
    initiateApplication();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }

  void initiateApplication() async {
    isPermissionGranted = await PermissionService.shared.requestUserPermission(onPermissionDenied: (){});
    if(isPermissionGranted){
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const SplashScreen()));
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    preCacheImages(context);
  }
}