import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'package:image_picker/image_picker.dart';

class UploadPage extends StatefulWidget {
  const UploadPage({Key? key}) : super(key: key);

  @override
  UploadPageState createState() => UploadPageState();
}

class UploadPageState extends State<UploadPage> {

  XFile? _imageFile;
  dynamic _pickError;
  String? extracted = 'Recognised Extracted Text Will Appear Here';
  final picker = ImagePicker();

  late FlutterTts flutterTts;
  String? engine;
  bool get isIOS => !kIsWeb && Platform.isIOS;
  bool get isAndroid => !kIsWeb && Platform.isAndroid;


  _imgFromGallery() async {
    try {
      final image = await picker.pickImage(source: ImageSource.gallery);
      EasyLoading.show(status: 'loading...');
      if (image != null) {
        // debugPrint(image.path);
        extracted = await FlutterTesseractOcr.extractText(image.path);
        _speak(extracted);
      } else {
        extracted = "Recognised extracted text will be shown here";
      }
      debugPrint(extracted);

      setState(() {
        if (image != null) {
          _imageFile = image;

          // if (_imageFile != null) {
          //   print(extracted);
          // } else
          //   extracted = "Recognised extracted text will be shown here";
        }
      });
    } catch (e) {
      setState(() {
        _pickError = e;
        debugPrint("$e");
      });
    }
  }

  Widget preview() {
    if (_imageFile != null) {
      if (kIsWeb) {
        EasyLoading.dismiss();
        return Image.network(
          _imageFile!.path,
          fit: BoxFit.cover,
        );
      } else {
        EasyLoading.dismiss();
        return Semantics(
            label: 'image_picked_image',
            child: Image.file(File(
              _imageFile!.path,
            )));
      }
    } else if (_pickError != null) {
      EasyLoading.dismiss();
      return const Text(
        'Error: Select An Image (.PNG,.JPG,.JPEG,..) \nand Wait a Few Seconds',
        textAlign: TextAlign.center,
      );
    } else {
      EasyLoading.dismiss();
      return const Text(
        'You have not yet picked an image\nUpload an Image And Wait A few Seconds',
        textAlign: TextAlign.center,
      );
    }
  }

  initTts() {
    flutterTts = FlutterTts();
    _setAwaitOptions();
    if (isAndroid) {
      _getDefaultEngine();
    }
    flutterTts.setCompletionHandler(() {});
    flutterTts.setErrorHandler((msg) {
      debugPrint("error: $msg");
    });
  }

  Future _getDefaultEngine() async {
    var engine = await flutterTts.getDefaultEngine;
    if (engine != null) {
      debugPrint("$engine");
    }
  }

  Future _speak(String? textToSpeak) async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setSpeechRate(0.45);
    await flutterTts.setVolume(1.0);
    await flutterTts.setPitch(1.0);

    if (textToSpeak != null) {
      if (textToSpeak.isNotEmpty) {
        await flutterTts.speak(textToSpeak);
      }
    }
  }

  Future _setAwaitOptions() async {
    await flutterTts.awaitSpeakCompletion(true);
  }

  @override
  void initState() {
    initTts();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    flutterTts.stop();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "OCR App",
      color: Colors.blue.shade100,
      theme: ThemeData(
        pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: CupertinoPageTransitionsBuilder(),
              TargetPlatform.iOS: CupertinoPageTransitionsBuilder()
            }
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'FiraSans',
      ),
      debugShowCheckedModeBanner: false,
      builder: EasyLoading.init(),
      home: Scaffold(
        backgroundColor: Colors.blue.shade50,
        appBar: AppBar(
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: const Text(
              "Extract text from image",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
            backgroundColor: Colors.blue.shade100,
            iconTheme: const IconThemeData(
              color: Colors.black,
            )),
        body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Center(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(color: Colors.grey.shade100),
                        height: 250,
                        width: 650,
                        child: Center(child: preview()),
                      ),
                      const SizedBox(height: 8),
                      Hero(
                        tag: const Key("upload"),
                        child: Card(
                          color: Colors.grey.shade700,
                          child: InkWell(
                            onTap: () {
                              _imgFromGallery();
                            },
                            // hoverColor: Colors.orange,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Colors.white),
                              ),
                              height: 45,
                              width: 400,
                              child: const Center(
                                child: Text(
                                  "Upload Image",
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 50),
                      Container(
                        color: Colors.orange.shade600,
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Card(
                            color: Colors.orange.shade500,
                            child: Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: SelectableText(
                                extracted.toString(),
                                style:
                                const TextStyle(color: Colors.white, fontSize: 16),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )),
        bottomNavigationBar: Container(
          width: 500,
          height: 10,
          color: Colors.grey.shade800,
        ),
      ),
    );
  }
}
