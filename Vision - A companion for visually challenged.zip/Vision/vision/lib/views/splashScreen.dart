import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rive/rive.dart';
import 'package:vision/views/homePage.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen>{
  ///Splash Screen page duration counter function
  startTime() async {
    var duration = const Duration(seconds: 5);
    return Timer(duration, navigationPage);
  }

  ///Navigate to Onboarding page after Splash screen
  void navigationPage() async{
    Navigator.of(context, rootNavigator: true).pushReplacement(CupertinoPageRoute(builder: (BuildContext context) => const HomePage()));
  }

  @override
  void initState() {
    super.initState();
    startTime();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ///Set Landscape Orientation as Default
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitDown,
      DeviceOrientation.portraitUp,
    ]);

    ///Remove Task bar and Navigation bar as overlays as Default
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    return Scaffold(
      backgroundColor: const Color(0XFFBBDEFB),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            SizedBox(
                height: 240,
                child: RiveAnimation.asset(
                    'assets/animation/logo.riv',
                    fit: BoxFit.scaleDown
                )),
            Text('Vision', style: TextStyle(fontSize: 70, fontWeight: FontWeight.w500, letterSpacing: 0.5)),
            SizedBox(height: 100),
          ],
        ),
      ),
    );
  }
}
