import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vision/views/ocr.dart';
import 'package:vision/views/readFromPicture.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Scaffold(
          backgroundColor: Colors.blue.shade100,
          appBar: AppBar(
            elevation: 0,
            toolbarHeight: 80,
            centerTitle: true,
            title: const Text("Vision",
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 30)),
            backgroundColor: Colors.blue.shade100,
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "A handy tool to extract text from images or using your camera",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          wordSpacing: 2,
                          fontSize: 25,
                          fontStyle: FontStyle.italic),
                    ),
                    const SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.all(30.0),
                      child: Image.asset(
                        "assets/images/ocr_image.png",
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text("Language : English", style: TextStyle(fontSize: 18)),
                    const SizedBox(height: 45),
                    Hero(
                      tag: const Key("ocr"),
                      child: Card(
                        color: Colors.grey.shade700,
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context, rootNavigator: true).push(
                                CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        const OcrScreen()));
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.white),
                            ),
                            height: 45,
                            width: 400,
                            child: const Center(
                              child: Text(
                                "Scan using Camera",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Hero(
                      tag: const Key("upload"),
                      child: Card(
                        color: Colors.grey.shade700,
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context, rootNavigator: true).push(
                                CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        const UploadPage()));
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.white),
                            ),
                            height: 45,
                            width: 400,
                            child: const Center(
                              child: Text(
                                "Upload Image",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: Container(
            width: 500,
            height: 10,
            color: Colors.grey.shade800,
          ),
        ),
        onWillPop: () async => false);
  }
}
